import { useLayoutEffect, useRef } from 'react';

interface LetterRevealOptions {
  /** Seconds to wait after the element enters the viewport before starting. */
  delay?: number;
  /** Seconds per letter (total duration is clamped between minDuration and maxDuration). */
  perLetter?: number;
  minDuration?: number;
  maxDuration?: number;
  /** Fraction of the element that must be visible before the reveal starts. */
  threshold?: number;
}

interface Glyph {
  left: number;
  right: number;
  top: number;
  bottom: number;
}

interface Line {
  glyphs: Glyph[];
  start: number; // index of first glyph in global order
  end: number; // index after last glyph in global order
  top: number;
  bottom: number;
}

const MASK_PROPS = ['mask-image', 'mask-size', 'mask-position', 'mask-repeat', 'mask-clip'] as const;

function setMask(el: HTMLElement, image: string, size: string, position: string) {
  for (const prefix of ['', '-webkit-']) {
    el.style.setProperty(`${prefix}mask-image`, image);
    el.style.setProperty(`${prefix}mask-size`, size);
    el.style.setProperty(`${prefix}mask-position`, position);
    el.style.setProperty(`${prefix}mask-repeat`, 'no-repeat');
  }
  // Keep the reveal strictly inside the transparent text wrapper. This prevents
  // the CSS mask from painting a rectangular layer over the cinematic background.
  for (const prefix of ['', '-webkit-']) {
    el.style.setProperty(`${prefix}mask-clip`, 'border-box');
  }
}

function clearMask(el: HTMLElement) {
  for (const prefix of ['', '-webkit-']) {
    for (const prop of MASK_PROPS) el.style.removeProperty(`${prefix}${prop}`);
  }
}

/** Measure every visible character of the element and group them into lines. */
function measureLines(el: HTMLElement): { lines: Line[]; total: number; avgWidth: number } {
  const origin = el.getBoundingClientRect();
  const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
  const glyphs: Glyph[] = [];
  const range = document.createRange();

  let node = walker.nextNode();
  while (node) {
    const text = node.textContent ?? '';
    for (let i = 0; i < text.length; i++) {
      range.setStart(node, i);
      range.setEnd(node, i + 1);
      const rects = range.getClientRects();
      if (!rects.length) continue; // collapsed whitespace
      const r = rects[0];
      if (r.width === 0 && r.height === 0) continue;
      glyphs.push({
        left: r.left - origin.left,
        right: r.right - origin.left,
        top: r.top - origin.top,
        bottom: r.bottom - origin.top,
      });
    }
    node = walker.nextNode();
  }

  const lines: Line[] = [];
  glyphs.forEach((g, index) => {
    const last = lines[lines.length - 1];
    const sameLine = last && Math.abs(g.top - last.top) < (g.bottom - g.top) * 0.5;
    if (sameLine) {
      last.glyphs.push(g);
      last.end = index + 1;
      last.bottom = Math.max(last.bottom, g.bottom);
    } else {
      lines.push({ glyphs: [g], start: index, end: index + 1, top: g.top, bottom: g.bottom });
    }
  });

  const avgWidth = glyphs.length
    ? glyphs.reduce((sum, g) => sum + (g.right - g.left), 0) / glyphs.length
    : 0;

  return { lines, total: glyphs.length, avgWidth };
}

/**
 * Reveals the element's text letter by letter, left to right, once it scrolls into view.
 *
 * It only applies a temporary CSS mask to the element itself, so the markup, layout,
 * gradient text (background-clip: text), filters and accessibility of the text are untouched.
 * The mask is removed completely when the animation finishes.
 */
export function useLetterReveal<T extends HTMLElement = HTMLElement>(options: LetterRevealOptions = {}) {
  const ref = useRef<T>(null);
  const {
    delay = 0,
    perLetter = 0.09,
    minDuration = 2.4,
    maxDuration = 3.6,
    threshold = 0.2,
  } = options;

  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;

    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    let raf = 0;
    let timer = 0;
    let cancelled = false;
    let observer: IntersectionObserver | null = null;

    // Hide immediately (before first paint) so there is no flash of the full text.
    setMask(el, 'linear-gradient(transparent, transparent)', '100% 100%', '0 0');

    const run = () => {
      const { lines, total, avgWidth } = measureLines(el);
      if (!total) {
        clearMask(el);
        return;
      }

      const width = el.getBoundingClientRect().width;
      const height = el.getBoundingClientRect().height;
      const edge = Math.max(avgWidth * 2, 8); // soft edge ~ two letters wide -> smooth letter-by-letter fade
      const duration = Math.min(maxDuration, Math.max(minDuration, total * perLetter));

      // Vertical bands: one per line, split halfway between neighbouring lines.
      const PAD = 80;
      const bands = lines.map((line, i) => {
        const top = i === 0 ? -PAD : (lines[i - 1].bottom + line.top) / 2;
        const bottom = i === lines.length - 1 ? height + PAD : (line.bottom + lines[i + 1].top) / 2;
        return { top, height: bottom - top };
      });

      const frontFor = (line: Line, p: number) => {
        if (p >= line.end) return width + edge * 2; // line completely revealed
        if (p <= line.start) return -edge; // line not started
        const local = p - line.start;
        const idx = Math.min(Math.floor(local), line.glyphs.length - 1);
        const frac = local - idx;
        const g = line.glyphs[idx];
        return g.left + (g.right - g.left) * frac + edge * 0.35;
      };

      const startTime = performance.now();

      const frame = (now: number) => {
        if (cancelled) return;
        const t = Math.min((now - startTime) / (duration * 1000), 1);
        const p = total * t;

        if (t >= 1) {
          clearMask(el);
          return;
        }

        const images: string[] = [];
        const sizes: string[] = [];
        const positions: string[] = [];

        lines.forEach((line, i) => {
          const x = frontFor(line, p);
          const solid = Math.max(0, x - edge);
          const fade = Math.max(0, x);
          images.push(`linear-gradient(to right, #000 0px, #000 ${solid}px, transparent ${fade}px)`);
          sizes.push(`${width + PAD * 2}px ${bands[i].height}px`);
          positions.push(`${-PAD}px ${bands[i].top}px`);
        });

        setMask(el, images.join(','), sizes.join(','), positions.join(','));
        raf = requestAnimationFrame(frame);
      };

      raf = requestAnimationFrame(frame);
    };

    const begin = () => {
      timer = window.setTimeout(() => {
        const fontsReady = (document as Document & { fonts?: { ready: Promise<unknown> } }).fonts?.ready;
        Promise.resolve(fontsReady).then(() => {
          if (!cancelled) run();
        });
      }, delay * 1000);
    };

    if ('IntersectionObserver' in window) {
      observer = new IntersectionObserver(
        (entries) => {
          if (entries.some((e) => e.isIntersecting)) {
            observer?.disconnect();
            begin();
          }
        },
        { threshold, rootMargin: '0px 0px -8% 0px' },
      );
      observer.observe(el);
    } else {
      begin();
    }

    return () => {
      cancelled = true;
      cancelAnimationFrame(raf);
      window.clearTimeout(timer);
      observer?.disconnect();
      clearMask(el);
    };
  }, [delay, perLetter, minDuration, maxDuration, threshold]);

  return ref;
}
