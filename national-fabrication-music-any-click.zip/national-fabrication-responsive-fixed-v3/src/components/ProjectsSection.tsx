import React, { useEffect, useRef, useState, useMemo, useCallback } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ChevronLeft, ChevronRight, ArrowUpRight } from 'lucide-react';
import { PROJECTS, Project } from '../data/projects';
import { useLetterReveal } from '../hooks/useLetterReveal';

gsap.registerPlugin(ScrollTrigger);

// Total cards forming the dense continuous ribbon ring (9 unique projects repeated 10 times)
const TOTAL_RING_CARDS = 90;

interface ProjectsSectionProps {
  onViewAll?: () => void;
}

export const ProjectsSection: React.FC<ProjectsSectionProps> = ({ onViewAll }) => {
  const titleRevealRef = useLetterReveal<HTMLHeadingElement>({ delay: 0.1 });
  const sectionRef = useRef<HTMLElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const animFrameRef = useRef<number | null>(null);
  
  // Continuous rotation angle in radians
  const [rotationAngle, setRotationAngle] = useState<number>(0);
  const rotationRef = useRef<number>(0);
  const scrollVelocityRef = useRef<number>(0);
  const isDraggingRef = useRef<boolean>(false);
  const dragStartXRef = useRef<number>(0);
  const dragStartAngleRef = useRef<number>(0);
  const isHoveredCenterRef = useRef<boolean>(false);

  // Responsive dimensions for the elliptical ring and center image
  const [dimensions, setDimensions] = useState({
    rx: 570,
    ry: 260,
    centerW: 560,
    centerH: 340,
    frontCardW: 36,
    frontCardH: 72,
    backCardW: 22,
    backCardH: 46,
    isMobile: false,
  });

  useEffect(() => {
    const handleResize = () => {
      const w = window.innerWidth;
      if (w < 640) {
        // Mobile screens: scaled down center card with wide open orbit clearance
        const safeRx = Math.min(Math.round(w * 0.43), 195);
        const safeRy = Math.min(Math.round(w * 0.28), 118);
        const safeCenterW = Math.min(Math.round(w * 0.48), 195);
        const safeCenterH = Math.min(Math.round(w * 0.30), 125);

        setDimensions({
          rx: safeRx,
          ry: safeRy,
          centerW: safeCenterW,
          centerH: safeCenterH,
          frontCardW: 16,
          frontCardH: 34,
          backCardW: 10,
          backCardH: 22,
          isMobile: true,
        });
      } else if (w < 1024) {
        // Tablets (preserved exactly)
        setDimensions({
          rx: 360,
          ry: 175,
          centerW: 420,
          centerH: 270,
          frontCardW: 28,
          frontCardH: 56,
          backCardW: 16,
          backCardH: 34,
          isMobile: false,
        });
      } else if (w < 1440) {
        // Laptops (preserved exactly)
        setDimensions({
          rx: 490,
          ry: 230,
          centerW: 490,
          centerH: 310,
          frontCardW: 32,
          frontCardH: 64,
          backCardW: 18,
          backCardH: 38,
          isMobile: false,
        });
      } else {
        // Large Desktop (preserved exactly)
        setDimensions({
          rx: 600,
          ry: 270,
          centerW: 560,
          centerH: 340,
          frontCardW: 36,
          frontCardH: 74,
          backCardW: 22,
          backCardH: 46,
          isMobile: false,
        });
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const anglePerCard = (2 * Math.PI) / TOTAL_RING_CARDS;

  // Active project calculation based on front-focus position (angle = 0 at bottom)
  const activeCardIndex = useMemo(() => {
    const twoPi = 2 * Math.PI;
    const normalized = ((-rotationAngle % twoPi) + twoPi) % twoPi;
    const cardIndex = Math.round(normalized / anglePerCard) % TOTAL_RING_CARDS;
    return (cardIndex + TOTAL_RING_CARDS) % TOTAL_RING_CARDS;
  }, [rotationAngle, anglePerCard]);

  const activeProjectIndex = activeCardIndex % PROJECTS.length;
  const activeProject: Project = PROJECTS[activeProjectIndex];

  // Rotate smoothly to a specific card index
  const rotateToCardIndex = useCallback((targetCardIdx: number) => {
    const targetAngle = -targetCardIdx * anglePerCard;
    const currentAngle = rotationRef.current;
    const twoPi = 2 * Math.PI;
    const diff = (targetAngle - currentAngle) % twoPi;
    const shortestDiff = ((diff + 3 * Math.PI) % twoPi) - Math.PI;
    const destinationAngle = currentAngle + shortestDiff;

    gsap.to(rotationRef, {
      current: destinationAngle,
      duration: 1.0,
      ease: 'power3.out',
    });
  }, [anglePerCard]);

  // CONTINUOUS ORBIT ENGINE: Seamless constant-speed loop with scroll & drag velocity damping
  useEffect(() => {
    const baseSpeed = 0.0016; // Cinematic, smooth constant orbit speed

    const animateLoop = () => {
      if (!isDraggingRef.current) {
        // Dampen scroll velocity smoothly back to 0
        scrollVelocityRef.current *= 0.94;

        // Advance angle by constant base speed plus any dampened scroll boost
        rotationRef.current += baseSpeed + scrollVelocityRef.current;
        setRotationAngle(rotationRef.current);
      }

      animFrameRef.current = requestAnimationFrame(animateLoop);
    };

    animFrameRef.current = requestAnimationFrame(animateLoop);

    return () => {
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
      }
    };
  }, []);

  // GSAP ScrollTrigger: Influences orbit speed and direction when scrolling through section
  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    let lastScrollY = window.scrollY;

    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      const delta = currentScrollY - lastScrollY;
      lastScrollY = currentScrollY;

      // Add a smooth momentum nudge to the orbit (does not stop constant movement)
      if (Math.abs(delta) > 0.5) {
        scrollVelocityRef.current += delta * 0.00018;
        // Clamp maximum velocity so it remains elegant and controlled
        scrollVelocityRef.current = Math.max(-0.04, Math.min(0.04, scrollVelocityRef.current));
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  // Direct mouse & touch spatial turntable dragging
  const handlePointerDown = (clientX: number) => {
    isDraggingRef.current = true;
    dragStartXRef.current = clientX;
    dragStartAngleRef.current = rotationRef.current;
  };

  const handlePointerMove = (clientX: number) => {
    if (!isDraggingRef.current) return;
    const deltaX = clientX - dragStartXRef.current;
    const sensitivity = dimensions.isMobile ? 0.006 : 0.0035;
    rotationRef.current = dragStartAngleRef.current + deltaX * sensitivity;
    setRotationAngle(rotationRef.current);
  };

  const handlePointerUp = () => {
    if (!isDraggingRef.current) return;
    isDraggingRef.current = false;
  };

  // Generate 90 cards array mapped to the 9 uploaded project photos
  const ringCards = useMemo(() => {
    return Array.from({ length: TOTAL_RING_CARDS }).map((_, i) => {
      const project = PROJECTS[i % PROJECTS.length];
      return {
        cardIndex: i,
        project,
      };
    });
  }, []);

  return (
    <section
      ref={sectionRef}
      id="completed-projects"
      className="relative w-full min-h-screen bg-[#080808] text-white overflow-hidden flex flex-col justify-between py-6 sm:py-8 select-none border-t border-white/10"
    >
      {/* Controlled subtle architectural backdrop tone matching Hero's dark atmosphere */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_75%_65%_at_50%_50%,rgba(255,255,255,0.025),transparent_75%)] pointer-events-none -z-10" />

      {/* ===================== TOP HEADER: EDITORIAL & CLEAN ===================== */}
      <div className="relative z-30 w-full max-w-[1520px] mx-auto px-4 sm:px-8 lg:px-12 flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-2">
        <div>
          <div className="flex items-center gap-3 mb-1.5">
            <span className="text-xs sm:text-sm font-semibold uppercase tracking-[0.2em] text-white border-b border-white pb-0.5">
              04 — Completed Projects
            </span>
            <span className="text-neutral-500 font-light text-xs hidden sm:inline">•</span>
            <span className="text-neutral-400 font-light text-xs tracking-wider uppercase hidden sm:inline">
              3D Architectural Orbit Gallery
            </span>
          </div>

          <h2 ref={titleRevealRef} className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-white leading-tight">
            COMPLETED PROJECTS
          </h2>

          <p className="text-xs sm:text-[13px] text-neutral-300 font-light mt-0.5 max-w-xl">
            A selection of projects delivered with precision, craftsmanship and attention to detail.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-start sm:items-end gap-3 self-end">
          {/* Orbit hint */}
          <div className="hidden sm:flex items-center gap-2 text-[11px] text-neutral-400 font-light">
            <span className="w-1.5 h-1.5 rounded-full bg-white/40 animate-pulse" />
            <span>Interactive 3D Orbit • Click or drag to rotate</span>
          </div>

          {/* VIEW ALL PROJECTS button */}
          <button
            id="view-all-projects-btn"
            onClick={onViewAll}
            className="flex items-center gap-1.5 text-[11px] sm:text-xs font-semibold uppercase tracking-[0.18em] text-white border-b border-white/50 pb-0.5 hover:border-white hover:text-white/90 transition-all group"
          >
            <span>View All Projects</span>
            <ArrowUpRight className="w-3 h-3 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </button>
        </div>
      </div>

      {/* ===================== MASSIVE 3D ELLIPTICAL RING STAGE (NO OUTER TEXT) ===================== */}
      <div
        ref={stageRef}
        className="relative z-10 w-full flex-1 flex items-center justify-center my-1 sm:my-4 cursor-grab active:cursor-grabbing min-h-[460px] sm:min-h-[620px] lg:min-h-[700px]"
        onMouseDown={(e) => handlePointerDown(e.clientX)}
        onMouseMove={(e) => handlePointerMove(e.clientX)}
        onMouseUp={handlePointerUp}
        onMouseLeave={handlePointerUp}
        onTouchStart={(e) => handlePointerDown(e.touches[0].clientX)}
        onTouchMove={(e) => handlePointerMove(e.touches[0].clientX)}
        onTouchEnd={handlePointerUp}
      >
        {/* Relative Coordinate Center (0,0) */}
        <div className="relative w-full h-full flex items-center justify-center">

          {/* ---------------- 1. DENSE CONTINUOUS 3D RIBBON OF CARDS (Hundreds of cards) ---------------- */}
          <div
            className="absolute inset-0 flex items-center justify-center pointer-events-none"
            style={{ perspective: '1600px', transformStyle: 'preserve-3d' }}
          >
            {ringCards.map(({ cardIndex, project }) => {
              // Parametric angle for this card
              const angle = rotationAngle + cardIndex * anglePerCard;

              // Elliptical coordinates
              const x = Math.sin(angle) * dimensions.rx;
              const y = Math.cos(angle) * dimensions.ry;

              // Depth factor: 0 at top (back of ellipse) to 1 at bottom (front of ellipse)
              const depthFactor = (Math.cos(angle) + 1) / 2; // 0 to 1

              // Dimensions and depth scaling
              const cardW = dimensions.backCardW + depthFactor * (dimensions.frontCardW - dimensions.backCardW);
              const cardH = dimensions.backCardH + depthFactor * (dimensions.frontCardH - dimensions.backCardH);
              const scale = 0.82 + depthFactor * 0.33; // 0.82 to 1.15
              const opacity = 0.52 + depthFactor * 0.48; // 0.52 to 1.0
              const blur = (1 - depthFactor) * 1.5; // Subtle blur on distant cards
              const zIndex = Math.round(depthFactor * 100);

              // Radial fan tilt angle: cards fan outward along the perimeter of the ellipse
              const fanAngleDeg = -Math.sin(angle) * 72;

              const isCurrentActive = cardIndex === activeCardIndex;

              return (
                <div
                  key={cardIndex}
                  onClick={(e) => {
                    e.stopPropagation();
                    rotateToCardIndex(cardIndex);
                  }}
                  className={`absolute pointer-events-auto cursor-pointer rounded-xs overflow-hidden transition-shadow duration-200 group ${
                    isCurrentActive
                      ? 'ring-2 ring-white shadow-[0_0_15px_rgba(255,255,255,0.7)]'
                      : 'hover:ring-1 hover:ring-white/70'
                  }`}
                  style={{
                    width: `${cardW}px`,
                    height: `${cardH}px`,
                    transform: `translate3d(${x}px, ${y}px, 0) translate(-50%, -50%) rotate(${fanAngleDeg}deg) scale(${scale})`,
                    opacity,
                    filter: blur > 0.4 ? `blur(${blur}px)` : 'none',
                    zIndex,
                    willChange: 'transform, opacity',
                  }}
                >
                  <img
                    src={project.image}
                    alt={project.name}
                    loading="lazy"
                    className="w-full h-full object-cover pointer-events-none"
                  />
                  {/* Subtle darkening gradient */}
                  <div className="absolute inset-0 bg-black/25 group-hover:bg-transparent transition-colors" />
                </div>
              );
            })}
          </div>

          {/* ---------------- 2. CENTER PROJECT WITH DETAILS DIRECTLY ON TOP OF IMAGE ---------------- */}
          {activeProject && (
            <div
              className="relative z-20 flex items-center justify-center pointer-events-auto"
              onMouseEnter={() => { isHoveredCenterRef.current = true; }}
              onMouseLeave={() => { isHoveredCenterRef.current = false; }}
            >
              {/* Featured Center Image Card */}
              <div
                className="relative rounded-xl sm:rounded-3xl overflow-hidden border border-white/20 bg-neutral-950 shadow-[0_20px_60px_rgba(0,0,0,0.95)] transition-all duration-500 group cursor-pointer"
                style={{
                  width: `${dimensions.centerW}px`,
                  height: `${dimensions.centerH}px`,
                }}
                onClick={() => {
                  const modal = document.querySelector('button[aria-label="Contact Us"]');
                  if (modal) modal.dispatchEvent(new MouseEvent('click', { bubbles: true }));
                }}
              >
                {/* Full-resolution Project Image */}
                <img
                  src={activeProject.image}
                  alt={activeProject.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />

                {/* Subtle dark gradient overlay directly over the image to guarantee high text readability */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/92 via-black/45 via-60% to-transparent pointer-events-none" />

                {/* PROJECT DETAILS DIRECTLY ON TOP OF IMAGE (Lower-left area) */}
                <div className="absolute bottom-0 inset-x-0 p-3 sm:p-7 text-left z-10">
                  
                  {/* PROJECT CATEGORY */}
                  <div className="flex items-center gap-1.5 sm:gap-2 mb-1 sm:mb-2">
                    <span className="w-1 h-1 sm:w-1.5 sm:h-1.5 rounded-full bg-neutral-400" />
                    <span className="text-[9px] sm:text-xs font-semibold tracking-[0.2em] text-neutral-400 uppercase">
                      {activeProject.type}
                    </span>
                  </div>

                  {/* PROJECT NAME */}
                  <h3 className="text-base sm:text-2xl lg:text-3xl font-bold tracking-tight text-white leading-tight sm:leading-snug drop-shadow-[0_2px_10px_rgba(0,0,0,0.9)] mb-1 sm:mb-2 line-clamp-1 sm:line-clamp-2">
                    {activeProject.name}
                  </h3>

                  {/* SHORT PROJECT DESCRIPTION */}
                  <p className="text-[10px] sm:text-xs lg:text-[13px] text-neutral-300 font-light leading-relaxed line-clamp-2 max-w-lg drop-shadow-[0_2px_8px_rgba(0,0,0,0.95)]">
                    {activeProject.description}
                  </p>

                </div>
              </div>
            </div>
          )}

        </div>
      </div>

      {/* ===================== BOTTOM NAVIGATION CONTROLS ===================== */}
      <div className="relative z-30 w-full max-w-[1520px] mx-auto px-4 sm:px-8 lg:px-12 flex items-center justify-center sm:justify-end gap-3 pt-1">
        
        {/* Step Navigation Arrows (Prev / Next) */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => rotateToCardIndex((activeCardIndex - 1 + TOTAL_RING_CARDS) % TOTAL_RING_CARDS)}
            className="w-8 h-8 sm:w-9 sm:h-9 rounded-full border border-white/20 bg-neutral-950/80 backdrop-blur-sm flex items-center justify-center text-white hover:bg-white hover:text-black transition-all cursor-pointer shadow-md"
            aria-label="Previous Project"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          
          <button
            onClick={() => rotateToCardIndex((activeCardIndex + 1) % TOTAL_RING_CARDS)}
            className="w-8 h-8 sm:w-9 sm:h-9 rounded-full border border-white/20 bg-neutral-950/80 backdrop-blur-sm flex items-center justify-center text-white hover:bg-white hover:text-black transition-all cursor-pointer shadow-md"
            aria-label="Next Project"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </section>
  );
};
