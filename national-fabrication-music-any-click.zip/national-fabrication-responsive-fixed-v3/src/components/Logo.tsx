import React from 'react';

interface LogoProps {
  className?: string;
}

export const Logo: React.FC<LogoProps> = ({ className = '' }) => {
  return (
    <div className={`flex flex-col items-center select-none ${className}`}>
      {/* NF Monogram Icon */}
      <div className="relative w-12 h-10 flex items-center justify-center">
        <svg
          viewBox="0 0 64 52"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full drop-shadow-[0_2px_8px_rgba(255,255,255,0.15)]"
        >
          {/* N - Silver / Metallic White */}
          <path
            d="M8 48V4H18.5L34 32.5V4H44V48H33.5L18 19.5V48H8Z"
            fill="url(#silverGradient)"
          />
          {/* F - Golden / Warm Bronze Accent */}
          <path
            d="M36 4H56V13H45V22.5H53.5V30H45V48H36V4Z"
            fill="url(#goldGradient)"
            style={{ mixBlendMode: 'screen' }}
          />

          <defs>
            <linearGradient id="silverGradient" x1="8" y1="4" x2="44" y2="48" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="45%" stopColor="#E2E8F0" />
              <stop offset="80%" stopColor="#94A3B8" />
              <stop offset="100%" stopColor="#64748B" />
            </linearGradient>
            <linearGradient id="goldGradient" x1="36" y1="4" x2="56" y2="48" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#FBBF24" />
              <stop offset="40%" stopColor="#F59E0B" />
              <stop offset="85%" stopColor="#D97706" />
              <stop offset="100%" stopColor="#B45309" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      {/* Brand Typography */}
      <div className="text-center mt-1">
        <div className="text-white text-[15px] font-extrabold tracking-[0.22em] leading-none uppercase">
          NATIONAL
        </div>
        <div className="text-neutral-400 text-[8.5px] font-medium tracking-[0.38em] leading-tight uppercase mt-1">
          FABRICATION
        </div>
      </div>
    </div>
  );
};
