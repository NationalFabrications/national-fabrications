import React from 'react';

export const ClientLogos: React.FC = () => {
  return (
    <div className="w-full">
      {/* Centered label with flanking lines */}
      <div className="flex items-center justify-center gap-4 mb-4 select-none">
        <div className="h-px bg-white/20 flex-1 max-w-xs md:max-w-md" />
        <span className="text-[12px] md:text-[13px] text-neutral-300 font-normal tracking-wide px-2 whitespace-nowrap">
          Our Prestigious Clients
        </span>
        <div className="h-px bg-white/20 flex-1 max-w-xs md:max-w-md" />
      </div>

      {/* Horizontal Client Logos Strip */}
      <div className="w-full overflow-x-auto no-scrollbar py-2">
        <div className="flex items-center justify-between min-w-max lg:min-w-0 lg:justify-between px-2 gap-4 lg:gap-2">
          
          {/* 1. NCC Limited */}
          <div className="flex items-center gap-3 group px-3 py-1 cursor-pointer transition-opacity hover:opacity-90">
            <div className="flex flex-col">
              <div className="flex items-center">
                <span className="text-xl font-black text-white tracking-wider font-sans">
                  NC
                </span>
                <span className="text-xl font-black text-[#F43F5E] tracking-wider font-sans">
                  C
                </span>
              </div>
              <span className="text-[10px] text-neutral-300 tracking-tight font-medium whitespace-nowrap mt-0.5">
                NCC Limited
              </span>
            </div>
          </div>

          <div className="h-9 w-px bg-white/20 shrink-0" />

          {/* 2. KSRTC */}
          <div className="flex items-center gap-2.5 group px-3 py-1 cursor-pointer transition-opacity hover:opacity-90">
            {/* KSRTC Circular Emblem */}
            <div className="w-9 h-9 shrink-0 relative flex items-center justify-center">
              <svg viewBox="0 0 36 36" fill="none" className="w-full h-full">
                <circle cx="18" cy="18" r="17" fill="#E11D48" stroke="#F59E0B" strokeWidth="1.5" />
                <circle cx="18" cy="18" r="14" stroke="#FFFFFF" strokeWidth="0.75" strokeDasharray="2 2" />
                {/* Mythical double-headed bird / Gandaberunda simplified silhouette */}
                <path
                  d="M18 7C14 7 11 11 11 15C11 18 13 21 18 24C23 21 25 18 25 15C25 11 22 7 18 7Z"
                  fill="#F59E0B"
                />
                <circle cx="15" cy="12" r="1.5" fill="#FFFFFF" />
                <circle cx="21" cy="12" r="1.5" fill="#FFFFFF" />
                <path d="M14 26L18 29L22 26" stroke="#F59E0B" strokeWidth="1.5" strokeLinecap="round" />
              </svg>
            </div>
            <div className="flex flex-col">
              <span className="text-base font-black text-white tracking-wider leading-none">
                KSRTC
              </span>
              <span className="text-[9.5px] text-neutral-300 font-normal leading-tight mt-1 whitespace-nowrap">
                Karnataka State Road<br />Transport Corporation
              </span>
            </div>
          </div>

          <div className="h-9 w-px bg-white/20 shrink-0" />

          {/* 3. KPTCL */}
          <div className="flex items-center gap-2.5 group px-3 py-1 cursor-pointer transition-opacity hover:opacity-90">
            {/* High-Voltage Transmission Tower Icon */}
            <div className="w-8 h-9 shrink-0 flex items-center justify-center">
              <svg viewBox="0 0 32 40" fill="none" className="w-full h-full stroke-white" strokeWidth="1.6">
                {/* Tower top */}
                <path d="M16 2L12 10H20L16 2Z" />
                {/* Top cross arms */}
                <line x1="6" y1="10" x2="26" y2="10" />
                <line x1="6" y1="10" x2="12" y2="18" />
                <line x1="26" y1="10" x2="20" y2="18" />
                {/* Middle section */}
                <line x1="4" y1="18" x2="28" y2="18" />
                <line x1="12" y1="10" x2="20" y2="18" />
                <line x1="20" y1="10" x2="12" y2="18" />
                {/* Legs down */}
                <line x1="12" y1="18" x2="8" y2="38" />
                <line x1="20" y1="18" x2="24" y2="38" />
                {/* X-braces */}
                <line x1="12" y1="18" x2="22" y2="28" />
                <line x1="20" y1="18" x2="10" y2="28" />
                <line x1="10" y1="28" x2="24" y2="38" />
                <line x1="22" y1="28" x2="8" y2="38" />
                <line x1="10" y1="28" x2="22" y2="28" />
                <line x1="8" y1="38" x2="24" y2="38" />
              </svg>
            </div>
            <div className="flex flex-col">
              <span className="text-base font-black text-white tracking-wider leading-none">
                KPTCL
              </span>
              <span className="text-[9.5px] text-neutral-300 font-normal leading-tight mt-1 whitespace-nowrap">
                Karnataka Power Transmission<br />Corporation Limited
              </span>
            </div>
          </div>

          <div className="h-9 w-px bg-white/20 shrink-0" />

          {/* 4. RAMI REDDY CONSTRUCTION */}
          <div className="flex items-center gap-2 group px-3 py-1 cursor-pointer transition-opacity hover:opacity-90">
            {/* Bold Stylized Red R */}
            <div className="shrink-0 flex items-center justify-center">
              <span className="text-3xl font-black text-[#E11D48] leading-none select-none font-sans">
                R
              </span>
            </div>
            <div className="flex flex-col">
              <span className="text-[13px] font-black text-white tracking-wider leading-none uppercase">
                RAMI REDDY
              </span>
              <span className="text-[9.5px] text-neutral-300 font-medium tracking-widest leading-tight mt-1 uppercase">
                CONSTRUCTION
              </span>
            </div>
          </div>

          <div className="h-9 w-px bg-white/20 shrink-0" />

          {/* 5. Indian Railways */}
          <div className="flex items-center gap-2.5 group px-3 py-1 cursor-pointer transition-opacity hover:opacity-90">
            <div className="w-8 h-8 shrink-0 flex items-center justify-center">
              <svg viewBox="0 0 36 36" fill="none" className="w-full h-full">
                <circle cx="18" cy="18" r="17" fill="#DC2626" stroke="#FFFFFF" strokeWidth="1" />
                <circle cx="18" cy="18" r="14" stroke="#FFFFFF" strokeWidth="0.75" />
                {/* Train engine and spoke wheel */}
                <circle cx="18" cy="18" r="7" stroke="#FFFFFF" strokeWidth="1.2" />
                <circle cx="18" cy="18" r="2.5" fill="#FFFFFF" />
                <line x1="18" y1="11" x2="18" y2="25" stroke="#FFFFFF" strokeWidth="1" />
                <line x1="11" y1="18" x2="25" y2="18" stroke="#FFFFFF" strokeWidth="1" />
                <line x1="13" y1="13" x2="23" y2="23" stroke="#FFFFFF" strokeWidth="1" />
                <line x1="13" y1="23" x2="23" y2="13" stroke="#FFFFFF" strokeWidth="1" />
                {/* Emblem top star */}
                <circle cx="18" cy="6" r="1" fill="#FFFFFF" />
              </svg>
            </div>
            <div className="flex flex-col">
              <span className="text-[12.5px] font-bold text-white tracking-wide leading-none whitespace-nowrap">
                Indian Railways
              </span>
            </div>
          </div>

          <div className="h-9 w-px bg-white/20 shrink-0" />

          {/* 6. SKIT */}
          <div className="flex items-center gap-2 group px-3 py-1 cursor-pointer transition-opacity hover:opacity-90">
            {/* SKIT Shield Emblem */}
            <div className="w-8 h-8 shrink-0 flex items-center justify-center">
              <svg viewBox="0 0 32 36" fill="none" className="w-full h-full">
                <path
                  d="M16 2L4 7V17C4 25 9.5 32 16 34C22.5 32 28 25 28 17V7L16 2Z"
                  fill="#1E3A8A"
                  stroke="#FFFFFF"
                  strokeWidth="1.2"
                />
                <circle cx="16" cy="16" r="5" stroke="#FFFFFF" strokeWidth="1" fill="#2563EB" />
                {/* Tech gear spokes */}
                <path d="M16 11V13M16 19V21M11 16H13M19 16H21" stroke="#FFFFFF" strokeWidth="1.5" strokeLinecap="round" />
                {/* Book / torch */}
                <path d="M13 24H19M16 22V25" stroke="#F59E0B" strokeWidth="1.2" strokeLinecap="round" />
              </svg>
            </div>
            <div className="flex flex-col">
              <span className="text-base font-black text-white tracking-wider leading-none">
                SKIT
              </span>
              <span className="text-[9.5px] text-neutral-300 font-normal leading-tight mt-1 whitespace-nowrap">
                Shri Krishna Institute<br />of Technology
              </span>
            </div>
          </div>

          <div className="h-9 w-px bg-white/20 shrink-0" />

          {/* 7. APEX BANK */}
          <div className="flex items-center gap-2.5 group px-3 py-1 cursor-pointer transition-opacity hover:opacity-90">
            {/* Apex Bank Triangular Logo */}
            <div className="w-8 h-8 shrink-0 flex items-center justify-center">
              <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
                {/* Main apex triangle */}
                <polygon points="16,3 2,28 30,28" fill="#F97316" stroke="#FFFFFF" strokeWidth="0.8" />
                {/* Green base tier */}
                <polygon points="16,14 6,28 26,28" fill="#15803D" />
                {/* Central inner white arch */}
                <path d="M13 28C13 24 19 24 19 28" fill="#FFFFFF" />
              </svg>
            </div>
            <div className="flex flex-col">
              <span className="text-[13px] font-black text-white tracking-wider leading-none">
                APEX BANK
              </span>
              <span className="text-[9px] text-neutral-300 font-normal leading-tight mt-1 whitespace-nowrap">
                The Apex Co-Operative Bank Ltd.
              </span>
            </div>
          </div>

          <div className="h-9 w-px bg-white/20 shrink-0" />

          {/* 8. Many More... */}
          <div className="flex items-center group px-3 py-1 cursor-pointer transition-opacity hover:opacity-90">
            <div className="flex flex-col text-neutral-200">
              <span className="text-[13px] font-medium leading-tight">Many</span>
              <span className="text-[13px] font-medium leading-tight">More...</span>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
