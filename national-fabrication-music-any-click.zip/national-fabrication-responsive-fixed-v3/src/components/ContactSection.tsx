import React, { useState } from 'react';
import {
  MessageSquare,
  FileText,
  Settings,
  Users,
  User,
  Mail,
  Phone,
  AppWindow,
  Send,
  MapPin,
  Building2,
  Home,
  Landmark,
  Wrench,
  Volume2,
  ChevronDown,
} from 'lucide-react';
import { useLetterReveal } from '../hooks/useLetterReveal';

interface ContactSectionProps {
  onSuccess?: () => void;
}

const SECTORS = [
  { icon: Building2, label: 'Commercial Projects' },
  { icon: Home, label: 'Residential Projects' },
  { icon: Landmark, label: 'Institutional Projects' },
  { icon: Wrench, label: 'Turnkey Solutions' },
  { icon: AppWindow, label: 'Aluminium Doors & Windows' },
  { icon: Volume2, label: 'Soundproof Windows' },
];

const PROJECT_TYPES = [
  'Commercial Turnkey Fabrication',
  'Architectural Facade & Glazing',
  'Aluminium Doors & Windows',
  'Soundproof Acoustic Windows',
  'Residential Villa Metalwork',
  'Institutional & Public Infrastructure',
  'Custom Industrial Fabrication',
];

export const ContactSection: React.FC<ContactSectionProps> = ({ onSuccess }) => {
  const titleRevealRef = useLetterReveal<HTMLHeadingElement>({ delay: 0.1 });
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    projectType: PROJECT_TYPES[0],
    message: '',
  });

  const [validationError, setValidationError] = useState('');
  const [statusMessage, setStatusMessage] = useState('');
  const [directWhatsappUrl, setDirectWhatsappUrl] = useState('');
  const [isOpening, setIsOpening] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError('');

    const trimmedName = formData.name.trim();
    const trimmedEmail = formData.email.trim();
    const trimmedPhone = formData.phone.trim();
    const trimmedMessage = formData.message.trim();

    // 1. Validate that Name, Email, Phone and Message are filled
    if (!trimmedName || !trimmedEmail || !trimmedPhone || !trimmedMessage) {
      setValidationError('Please fill in Name, Email Address, Phone Number, and Message.');
      return;
    }

    // 2. Create WhatsApp enquiry message containing all submitted information
    const whatsappText = `New Website Enquiry — National Fabrication

Name: ${trimmedName}
Email: ${trimmedEmail}
Phone: ${trimmedPhone}
Project Type: ${formData.projectType}
Message: ${trimmedMessage}`;

    // 3. WhatsApp link for National Fabrication number: +91 9845113513
    const url = `https://wa.me/919845113513?text=${encodeURIComponent(whatsappText)}`;
    setDirectWhatsappUrl(url);

    // 7. Show small transition message
    setIsOpening(true);
    setStatusMessage('Opening WhatsApp...');

    try {
      // 5. Open WhatsApp using anchor click (safest across browsers/iframes)
      const a = document.createElement('a');
      a.href = url;
      a.target = '_blank';
      a.rel = 'noopener noreferrer';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);

      if (onSuccess) onSuccess();

      setTimeout(() => {
        setIsOpening(false);
      }, 1500);
    } catch (err) {
      // 6. Do NOT pretend the form was submitted if WhatsApp could not be opened
      setIsOpening(false);
      setStatusMessage('Could not open WhatsApp automatically. Please click the direct link below.');
    }
  };

  return (
    <section
      id="contact"
      className="relative w-full bg-[#080808] text-white py-14 sm:py-20 lg:py-24 select-none overflow-hidden border-t border-white/10"
    >
      {/* Controlled subtle architectural backdrop tone matching Hero's dark aesthetic */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_75%_55%_at_50%_35%,rgba(255,255,255,0.025),transparent_75%)] pointer-events-none -z-10" />

      <div className="relative z-10 w-full max-w-[1520px] mx-auto px-4 sm:px-6 lg:px-12 space-y-6 sm:space-y-8">

        {/* ========================================================================= */}
        {/* ===================== TOP HERO BANNER OF THE SECTION ==================== */}
        {/* ========================================================================= */}
        <div className="relative rounded-2xl sm:rounded-3xl border border-white/15 bg-neutral-950/85 backdrop-blur-md overflow-hidden p-6 sm:p-10 lg:p-12 shadow-2xl">
          
          {/* Architectural Background Image of Illuminated Building Facade */}
          <div className="absolute inset-0 pointer-events-none overflow-hidden">
            <img
              src="https://res.cloudinary.com/p8mbdjxv/image/upload/v1791151258/Gemini_Generated_Image_wgqudiwgqudiwgqu.png"
              alt="Illuminated architectural facade"
              className="w-full h-full object-cover opacity-25 object-right"
            />
            {/* Deep gradient overlays for maximum text clarity */}
            <div className="absolute inset-0 bg-gradient-to-r from-neutral-950 via-neutral-950/90 via-55% to-neutral-950/40" />
            <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-transparent to-neutral-950/40" />
          </div>

          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start justify-between">
            
            {/* Left Content */}
            <div className="lg:col-span-8 max-w-2xl">
              
              {/* Section Tag */}
              <div className="flex items-center gap-2 mb-3">
                <span className="text-xs sm:text-sm font-semibold uppercase tracking-[0.25em] text-white border-b border-white pb-0.5">
                  05 — Contact Us
                </span>
                <span className="w-8 h-[1px] bg-white/30 ml-1" />
              </div>

              {/* Main Headline Matching Hero Display Typography */}
              <h2 ref={titleRevealRef} className="text-3xl sm:text-5xl lg:text-[56px] font-bold tracking-[-0.03em] metallic-text leading-[1.05] mb-4">
                Let’s Build
                <br />
                Your Next Project
              </h2>

              <p className="text-xs sm:text-sm lg:text-[15px] text-neutral-300 font-light leading-relaxed max-w-xl mb-8">
                Have a project in mind? Get in touch with our team for enquiries, consultations or custom fabrication solutions.
              </p>

              {/* 4 Architectural Feature Pills */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3">
                <div className="flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl border border-white/10 bg-white/[0.03] backdrop-blur-md">
                  <MessageSquare className="w-4 h-4 text-neutral-300 shrink-0" />
                  <span className="text-[11px] sm:text-xs text-neutral-200 font-medium tracking-tight">Quick Response</span>
                </div>

                <div className="flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl border border-white/10 bg-white/[0.03] backdrop-blur-md">
                  <FileText className="w-4 h-4 text-neutral-300 shrink-0" />
                  <span className="text-[11px] sm:text-xs text-neutral-200 font-medium tracking-tight">Project Consultation</span>
                </div>

                <div className="flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl border border-white/10 bg-white/[0.03] backdrop-blur-md">
                  <Settings className="w-4 h-4 text-neutral-300 shrink-0" />
                  <span className="text-[11px] sm:text-xs text-neutral-200 font-medium tracking-tight">Custom Solutions</span>
                </div>

                <div className="flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl border border-white/10 bg-white/[0.03] backdrop-blur-md">
                  <Users className="w-4 h-4 text-neutral-300 shrink-0" />
                  <span className="text-[11px] sm:text-xs text-neutral-200 font-medium tracking-tight">Trusted Support</span>
                </div>
              </div>

            </div>

            {/* Right Meta Column (as in reference mockup) */}
            <div className="hidden lg:flex lg:col-span-4 flex-col items-end text-right justify-between self-stretch pr-2">
              <div className="space-y-1 text-xs font-medium tracking-[0.2em] uppercase text-neutral-400">
                <div>INTERIOR</div>
                <div>EXTERIOR</div>
                <div>TURNKEY</div>
              </div>

              <div className="space-y-1 mt-8 pt-6 border-t border-white/15 text-right">
                <div className="text-[10px] tracking-[0.22em] uppercase text-neutral-400 font-medium">
                  FABRICATION SOLUTIONS
                </div>
                <div className="text-xs tracking-[0.2em] uppercase text-white font-semibold">
                  SINCE 2004
                </div>
              </div>
            </div>

          </div>

        </div>

        {/* ========================================================================= */}
        {/* ===================== MIDDLE ROW: FORM + GET IN TOUCH =================== */}
        {/* ========================================================================= */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">

          {/* ---------------- LEFT: SEND US A MESSAGE FORM ---------------- */}
          <div className="lg:col-span-6 rounded-2xl sm:rounded-3xl border border-white/15 bg-neutral-950/85 backdrop-blur-md p-6 sm:p-8 flex flex-col justify-between shadow-xl">
            <div>
              <h3 className="text-xl sm:text-2xl font-bold tracking-tight text-white mb-1">
                Send Us a <span className="text-neutral-300">Message</span>
              </h3>
              <p className="text-xs sm:text-[13px] text-neutral-400 font-light mb-6">
                Share your requirements and our team will get back to you shortly.
              </p>

              <form onSubmit={handleSubmit} className="space-y-3.5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  {/* Name */}
                  <div className="relative">
                    <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400">
                      <User className="w-4 h-4" />
                    </div>
                    <input
                      type="text"
                      required
                      placeholder="Your Name *"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full pl-10 pr-4 py-3 rounded-xl border border-white/15 bg-white/[0.03] text-xs sm:text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-white/40 focus:bg-white/[0.06] transition-all"
                    />
                  </div>

                  {/* Email */}
                  <div className="relative">
                    <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400">
                      <Mail className="w-4 h-4" />
                    </div>
                    <input
                      type="email"
                      required
                      placeholder="Email Address *"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full pl-10 pr-4 py-3 rounded-xl border border-white/15 bg-white/[0.03] text-xs sm:text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-white/40 focus:bg-white/[0.06] transition-all"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  {/* Phone */}
                  <div className="relative">
                    <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400">
                      <Phone className="w-4 h-4" />
                    </div>
                    <input
                      type="tel"
                      required
                      placeholder="Phone Number *"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full pl-10 pr-4 py-3 rounded-xl border border-white/15 bg-white/[0.03] text-xs sm:text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-white/40 focus:bg-white/[0.06] transition-all"
                    />
                  </div>

                  {/* Project Type Dropdown */}
                  <div className="relative">
                    <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400">
                      <AppWindow className="w-4 h-4" />
                    </div>
                    <select
                      value={formData.projectType}
                      onChange={(e) => setFormData({ ...formData, projectType: e.target.value })}
                      className="w-full pl-10 pr-8 py-3 rounded-xl border border-white/15 bg-neutral-900 text-xs sm:text-sm text-white focus:outline-none focus:border-white/40 transition-all appearance-none cursor-pointer"
                    >
                      {PROJECT_TYPES.map((type) => (
                        <option key={type} value={type} className="bg-neutral-900 text-white">
                          {type}
                        </option>
                      ))}
                    </select>
                    <ChevronDown className="w-4 h-4 text-neutral-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  </div>
                </div>

                {/* Message */}
                <div className="relative">
                  <div className="absolute left-3.5 top-3.5 text-neutral-400">
                    <MessageSquare className="w-4 h-4" />
                  </div>
                  <textarea
                    required
                    rows={4}
                    placeholder="Your Message *"
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full pl-10 pr-4 py-3 rounded-xl border border-white/15 bg-white/[0.03] text-xs sm:text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-white/40 focus:bg-white/[0.06] transition-all resize-none"
                  />
                </div>

                {validationError && (
                  <p className="text-xs text-rose-400">
                    {validationError}
                  </p>
                )}

                {/* Submit Row Matching Hero Styling */}
                <div className="flex flex-col sm:flex-row sm:items-center gap-3 pt-1">
                  <button
                    type="submit"
                    disabled={isOpening}
                    className="w-full sm:w-auto bg-white text-black font-semibold text-xs sm:text-sm px-7 py-3 rounded-full flex items-center justify-center gap-2 hover:bg-neutral-200 transition-all shadow-md cursor-pointer disabled:opacity-75"
                  >
                    <span>{isOpening ? 'Opening WhatsApp...' : 'Send Message'}</span>
                    <Send className="w-3.5 h-3.5 text-black" />
                  </button>

                  {statusMessage && (
                    <div className="flex items-center gap-2 text-xs text-neutral-300">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" />
                      <span>{statusMessage}</span>
                      {directWhatsappUrl && (
                        <a
                          href={directWhatsappUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-white underline hover:text-neutral-200 ml-1 font-medium"
                        >
                          Click to open
                        </a>
                      )}
                    </div>
                  )}
                </div>
              </form>
            </div>
          </div>

          {/* ---------------- RIGHT: GET IN TOUCH + ARCHITECTURAL FACADE CUTOUT ---------------- */}
          <div className="lg:col-span-6 rounded-2xl sm:rounded-3xl border border-white/15 bg-neutral-950/85 backdrop-blur-md overflow-hidden shadow-xl grid grid-cols-1 md:grid-cols-12">
            
            {/* Left Contact Details (7 cols) */}
            <div className="md:col-span-7 p-6 sm:p-8 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-[10px] uppercase tracking-wider text-neutral-400 font-medium">National Fabrication • Since 2004</span>
                </div>
                <h3 className="text-xl sm:text-2xl font-bold tracking-tight text-white mb-1">
                  Get In <span className="text-neutral-300">Touch</span>
                </h3>
                <p className="text-xs sm:text-[13px] text-neutral-400 font-light mb-6">
                  We’re always ready to discuss your project, provide expert guidance and offer the right fabrication solutions.
                </p>

                {/* Contact Tiles */}
                <div className="space-y-3">
                  
                  {/* Email */}
                  <a
                    href="mailto:info@nationalfabrication.com"
                    className="flex items-start gap-3.5 p-3.5 rounded-xl border border-white/10 bg-white/[0.02] hover:bg-white/[0.06] hover:border-white/25 transition-all group"
                  >
                    <div className="w-9 h-9 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center shrink-0 group-hover:border-white/30 transition-colors">
                      <Mail className="w-4 h-4 text-neutral-300" />
                    </div>
                    <div>
                      <div className="text-[10px] uppercase tracking-wider text-neutral-400 font-medium">
                        Email Us
                      </div>
                      <div className="text-xs sm:text-sm font-semibold text-white tracking-tight mt-0.5">
                        info@nationalfabrication.com
                      </div>
                      <div className="text-[10px] text-neutral-400 font-light mt-0.5">
                        We reply within 24 hours
                      </div>
                    </div>
                  </a>

                  {/* Visit Our Office */}
                  <div className="flex items-start gap-3.5 p-3.5 rounded-xl border border-white/10 bg-white/[0.02] group">
                    <div className="w-9 h-9 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center shrink-0">
                      <MapPin className="w-4 h-4 text-neutral-300" />
                    </div>
                    <div>
                      <div className="text-[10px] uppercase tracking-wider text-neutral-400 font-medium">
                        Visit Our Office
                      </div>
                      <div className="text-xs sm:text-sm font-semibold text-white tracking-tight mt-0.5">
                        Jayanagar, Bangalore, Karnataka
                      </div>
                      <div className="text-[10px] text-neutral-400 font-light mt-0.5">
                        Near Dairy Circle, Bangalore - 560029
                      </div>
                    </div>
                  </div>

                </div>
              </div>
            </div>

            {/* Right Architectural Facade Image Cutout (5 cols) */}
            <div className="hidden md:block md:col-span-5 relative min-h-[300px]">
              <img
                src="https://res.cloudinary.com/p8mbdjxv/image/upload/v1791151261/Gemini_Generated_Image_1tdw1f1tdw1f1tdw.png"
                alt="Architectural facade vertical mullions"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-neutral-950/80 via-transparent to-transparent" />
            </div>

          </div>

        </div>

        {/* ========================================================================= */}
        {/* ===================== BOTTOM BANNER: WE WORK ACROSS SECTORS ============== */}
        {/* ========================================================================= */}
        <div className="rounded-2xl sm:rounded-3xl border border-white/15 bg-neutral-950/85 backdrop-blur-md p-5 sm:p-7 shadow-xl flex flex-col lg:flex-row items-center justify-between gap-6">
          
          {/* Left Title */}
          <div className="text-center lg:text-left shrink-0">
            <h4 className="text-lg sm:text-xl font-bold tracking-tight text-white leading-tight">
              We Work Across
              <br />
              <span className="text-neutral-300">Multiple Sectors</span>
            </h4>
            <div className="w-10 h-[1.5px] bg-white/40 mt-2 mx-auto lg:mx-0 rounded-full" />
          </div>

          {/* Right 6 Sector Badges */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 w-full lg:w-auto flex-1 lg:pl-6">
            {SECTORS.map((sector) => {
              const IconComp = sector.icon;
              return (
                <div
                  key={sector.label}
                  className="flex flex-col items-center justify-center p-3 rounded-xl border border-white/10 bg-white/[0.02] text-center hover:border-white/25 hover:bg-white/[0.05] transition-all group"
                >
                  <div className="w-7 h-7 rounded-full bg-white/5 border border-white/10 flex items-center justify-center mb-1.5 shrink-0 group-hover:border-white/30 transition-colors">
                    <IconComp className="w-3.5 h-3.5 text-neutral-300" />
                  </div>
                  <span className="text-[10px] sm:text-[11px] font-medium text-neutral-200 tracking-tight leading-tight">
                    {sector.label}
                  </span>
                </div>
              );
            })}
          </div>

        </div>

      </div>
    </section>
  );
};
