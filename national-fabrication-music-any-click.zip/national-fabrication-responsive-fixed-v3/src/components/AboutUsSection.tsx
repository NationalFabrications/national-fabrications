import React, { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import {
  Train,
  MapPin,
  Layers,
  Building2,
  Wrench,
  AppWindow,
  Volume2,
  Settings,
  Shield,
  Clock,
  Sparkles,
  ArrowUpRight,
} from 'lucide-react';
import { useLetterReveal } from '../hooks/useLetterReveal';

gsap.registerPlugin(ScrollTrigger);

interface AboutUsSectionProps {
  onOpenContact?: () => void;
}

const LANDMARK_IMAGE = 'https://res.cloudinary.com/p8mbdjxv/image/upload/v1791151270/Gemini_Generated_Image_u1xw4gu1xw4gu1xw.png';

const CAPABILITIES = [
  { icon: Layers, label: 'Interior Fabrication' },
  { icon: Building2, label: 'Exterior Fabrication' },
  { icon: Wrench, label: 'Turnkey Project Execution' },
  { icon: AppWindow, label: 'Aluminium Doors & Windows' },
  { icon: Volume2, label: 'Soundproof Windows' },
  { icon: Settings, label: 'Custom Fabrication Solutions' },
];

const HIGHLIGHTS = [
  {
    icon: Clock,
    title: '25+ YEARS',
    subtitle: 'OF EXPERIENCE',
  },
  {
    icon: Shield,
    title: 'SINCE 2004',
    subtitle: 'ESTABLISHED HERITAGE',
  },
  {
    icon: Sparkles,
    title: 'MULTIPLE LANDMARK',
    subtitle: 'INFRASTRUCTURE PROJECTS',
  },
  {
    icon: Layers,
    title: 'INTERIOR • EXTERIOR',
    subtitle: 'TURNKEY SOLUTIONS',
  },
];

export const AboutUsSection: React.FC<AboutUsSectionProps> = ({ onOpenContact }) => {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const landmarkRef = useRef<HTMLDivElement>(null);
  const titleRevealRef = useLetterReveal<HTMLHeadingElement>({ delay: 0.15 });

  useEffect(() => {
    const section = sectionRef.current;
    const headline = headlineRef.current;
    const landmark = landmarkRef.current;

    if (!section || !headline || !landmark) return;

    const ctx = gsap.context(() => {
      // Reveal headline & capabilities
      gsap.fromTo(
        headline.querySelectorAll('.editorial-reveal'),
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.9,
          stagger: 0.1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: headline,
            start: 'top 82%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Reveal landmark spotlight
      gsap.fromTo(
        landmark.querySelectorAll('.landmark-reveal'),
        { opacity: 0, y: 35 },
        {
          opacity: 1,
          y: 0,
          duration: 1.0,
          stagger: 0.12,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: landmark,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="about"
      className="relative w-full bg-[#080808] text-white py-14 sm:py-20 lg:py-24 select-none overflow-hidden border-t border-white/10"
    >
      {/* Subtle architectural radial lighting */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_75%_50%_at_50%_35%,rgba(59,130,246,0.03),transparent_75%)] pointer-events-none -z-10" />

      <div className="relative z-10 w-full max-w-[1520px] mx-auto px-4 sm:px-6 lg:px-12 space-y-12 sm:space-y-16">

        {/* ========================================================================= */}
        {/* ===================== EDITORIAL HEADER & INTRO ========================= */}
        {/* ========================================================================= */}
        <div ref={headlineRef} className="space-y-8">
          
          {/* Chapter Marker */}
          <div className="editorial-reveal flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="text-xs sm:text-sm font-semibold uppercase tracking-[0.25em] text-white border-b border-white pb-0.5">
                02 — About Us
              </span>
              <span className="text-neutral-500 font-light text-xs hidden sm:inline">•</span>
              <span className="text-neutral-400 font-light text-xs tracking-wider uppercase hidden sm:inline">
                Established Fabrication & Solutions
              </span>
            </div>

            <div className="flex items-center gap-2 px-3 sm:px-4 py-1.5 rounded-full border border-white/15 bg-white/[0.03] backdrop-blur-md text-white text-xs font-light shadow-sm">
              <span className="w-1.5 h-1.5 rounded-full bg-neutral-400" />
              <span className="tracking-wider uppercase text-[11px] font-medium text-neutral-300">Since 2004</span>
            </div>
          </div>

          {/* Main Title & Editorial Statement */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-12 items-start">
            
            <div className="lg:col-span-7 space-y-4">
              <div className="editorial-reveal text-xs sm:text-sm font-semibold tracking-[0.22em] uppercase text-neutral-400">
                ABOUT NATIONAL FABRICATION
              </div>

              <h2 ref={titleRevealRef} className="editorial-reveal text-3xl sm:text-5xl lg:text-[54px] font-bold tracking-[-0.03em] metallic-text leading-[1.05]">
                25+ YEARS OF BUILDING WITH PRECISION
              </h2>

              <p className="editorial-reveal text-sm sm:text-base lg:text-[17px] text-neutral-300 font-light leading-relaxed max-w-2xl pt-1">
                National Fabrication provides interior and exterior fabrication solutions for commercial, residential, institutional and infrastructure projects.
              </p>
            </div>

            {/* Company Highlights Ribbon (No invented statistics or project counts) */}
            <div className="lg:col-span-5 grid grid-cols-2 gap-2.5 sm:gap-3">
              {HIGHLIGHTS.map((item) => {
                const IconComp = item.icon;
                return (
                  <div
                    key={item.title}
                    className="editorial-reveal p-3.5 sm:p-4 rounded-2xl border border-white/10 bg-neutral-950/70 backdrop-blur-md flex flex-col justify-between hover:border-white/25 transition-all shadow-sm group"
                  >
                    <div className="w-7 h-7 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center mb-3 text-neutral-300 group-hover:text-white transition-colors">
                      <IconComp className="w-3.5 h-3.5" />
                    </div>
                    <div>
                      <div className="text-xs sm:text-sm font-bold text-white tracking-tight leading-tight">
                        {item.title}
                      </div>
                      <div className="text-[9px] sm:text-[10px] tracking-wider uppercase text-neutral-400 font-medium mt-0.5">
                        {item.subtitle}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

          </div>

          {/* Capabilities Grid */}
          <div className="editorial-reveal pt-4 border-t border-white/10">
            <div className="text-[11px] sm:text-xs font-semibold uppercase tracking-[0.22em] text-neutral-400 mb-4">
              OUR CAPABILITIES INCLUDE
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 sm:gap-3">
              {CAPABILITIES.map((cap) => {
                const IconComp = cap.icon;
                return (
                  <div
                    key={cap.label}
                    className="p-3 sm:p-3.5 rounded-xl border border-white/10 bg-white/[0.02] hover:bg-white/[0.06] hover:border-white/25 transition-all flex flex-col items-start gap-2 shadow-sm group cursor-default"
                  >
                    <div className="w-7 h-7 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-neutral-300 group-hover:text-white transition-colors">
                      <IconComp className="w-3.5 h-3.5" />
                    </div>
                    <span className="text-xs sm:text-[12.5px] font-medium text-neutral-200 tracking-tight leading-snug">
                      {cap.label}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

        </div>

        {/* ========================================================================= */}
        {/* ===================== LANDMARK PROJECT SPOTLIGHT ======================= */}
        {/* ========================================================================= */}
        <div ref={landmarkRef} className="rounded-2xl sm:rounded-3xl border border-white/15 bg-neutral-950/85 backdrop-blur-md overflow-hidden p-6 sm:p-8 lg:p-10 shadow-2xl">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Left: Authentic Landmark Project Photograph */}
            <div className="landmark-reveal lg:col-span-7 xl:col-span-8 w-full">
              <div className="relative rounded-2xl overflow-hidden border border-white/20 bg-neutral-950 aspect-[16/10] sm:aspect-[16/9] w-full group shadow-2xl">
                <img
                  src={LANDMARK_IMAGE}
                  alt="Sir M. Visvesvaraya Terminal Baiyappanahalli Bengaluru"
                  className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-[1.03]"
                />
                
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-black/20 pointer-events-none" />

                <div className="absolute top-3.5 left-3.5 sm:top-5 sm:left-5 z-10 flex items-center gap-2 px-3 sm:px-4 py-1.5 rounded-full bg-black/80 backdrop-blur-md border border-white/20 text-white text-[11px] font-medium shadow-md">
                  <Train className="w-3.5 h-3.5 text-neutral-300" />
                  <span className="tracking-wider uppercase text-[10px] sm:text-[11px] font-medium">
                    Railway Infrastructure Landmark
                  </span>
                </div>

                <div className="absolute bottom-0 inset-x-0 p-4 sm:p-6 text-left z-10">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-neutral-400" />
                    <span className="text-[10px] sm:text-xs font-semibold tracking-[0.2em] text-neutral-400 uppercase">
                      Baiyappanahalli • Bengaluru
                    </span>
                  </div>
                  <h3 className="text-xl sm:text-2xl lg:text-3xl font-bold tracking-tight text-white leading-tight">
                    Sir M. Visvesvaraya Terminal
                  </h3>
                  <p className="text-xs sm:text-sm text-neutral-300 font-light mt-1 max-w-xl leading-relaxed">
                    High-span structural steel framework, canopy structures & architectural glazing
                  </p>
                </div>
              </div>
            </div>

            {/* Right: Factual Statement & Details */}
            <div className="landmark-reveal lg:col-span-5 xl:col-span-4 space-y-5">
              
              <div className="flex items-center gap-2">
                <span className="text-[11px] sm:text-xs font-semibold uppercase tracking-[0.22em] text-neutral-400">
                  LANDMARK PROJECT HIGHLIGHT
                </span>
              </div>

              <div>
                <h3 className="text-2xl sm:text-3xl font-bold tracking-tight text-white leading-tight">
                  SIR M. VISVESVARAYA TERMINAL
                </h3>
                <div className="flex items-center gap-2 text-neutral-300 text-xs sm:text-sm font-light tracking-tight mt-1.5">
                  <MapPin className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                  <span>Baiyappanahalli, Bengaluru</span>
                </div>
              </div>

              {/* Exact user requirement wording */}
              <div className="border-l-2 border-white/40 pl-4 py-2 bg-white/[0.02] rounded-r-xl">
                <p className="text-xs sm:text-[13.5px] text-neutral-200 font-light leading-relaxed italic">
                  “National Fabrication was part of this landmark project, contributing to its execution under contractor M. V. Satyanarayana.”
                </p>
              </div>

              <div className="space-y-2 text-xs sm:text-[13px] text-neutral-300 font-light leading-relaxed">
                <div className="flex items-start gap-2.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-neutral-400 mt-1.5 shrink-0" />
                  <span>High-capacity architectural passenger concourse metalwork</span>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-neutral-400 mt-1.5 shrink-0" />
                  <span>Structural steel canopy fabrication and specialized transit glazing</span>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-neutral-400 mt-1.5 shrink-0" />
                  <span>Rigid safety and precision tolerances executed on schedule</span>
                </div>
              </div>

              {onOpenContact && (
                <div className="pt-2">
                  <button
                    onClick={onOpenContact}
                    className="group bg-white text-black font-semibold text-xs sm:text-sm px-6 py-2.5 rounded-full flex items-center gap-2.5 hover:bg-neutral-200 transition-all shadow-md cursor-pointer"
                  >
                    <span>Consult on Infrastructure Projects</span>
                    <ArrowUpRight className="w-3.5 h-3.5 text-black group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                  </button>
                </div>
              )}

            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
