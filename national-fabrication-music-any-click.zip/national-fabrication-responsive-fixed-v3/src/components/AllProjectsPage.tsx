import React, { useEffect, useRef, useState } from 'react';
import { ArrowLeft, ChevronLeft } from 'lucide-react';
import { PROJECTS, CATEGORIES } from '../data/projects';

interface AllProjectsPageProps {
  onBack: () => void;
}

export const AllProjectsPage: React.FC<AllProjectsPageProps> = ({ onBack }) => {
  const pageRef = useRef<HTMLDivElement>(null);
  const [activeCategory, setActiveCategory] = useState<string>('ALL');
  const [mounted, setMounted] = useState(false);

  // Entrance animation
  useEffect(() => {
    requestAnimationFrame(() => setMounted(true));
  }, []);

  // Scroll to top on mount
  useEffect(() => {
    if (pageRef.current) {
      pageRef.current.scrollTop = 0;
    }
    window.scrollTo(0, 0);
  }, []);

  const filteredProjects =
    activeCategory === 'ALL'
      ? PROJECTS
      : PROJECTS.filter((p) => p.categories.includes(activeCategory));

  return (
    <div
      ref={pageRef}
      className="fixed inset-0 z-[9999] bg-[#080808] text-white overflow-y-auto"
      style={{
        opacity: mounted ? 1 : 0,
        transform: mounted ? 'translateY(0)' : 'translateY(20px)',
        transition: 'opacity 0.45s cubic-bezier(0.16,1,0.3,1), transform 0.45s cubic-bezier(0.16,1,0.3,1)',
      }}
    >
      {/* Subtle radial backdrop */}
      <div className="fixed inset-0 bg-[radial-gradient(ellipse_70%_55%_at_50%_20%,rgba(255,255,255,0.02),transparent_70%)] pointer-events-none" />

      {/* ── STICKY HEADER ── */}
      <header className="sticky top-0 z-50 w-full border-b border-white/10 bg-[#080808]/90 backdrop-blur-md">
        <div className="max-w-[1520px] mx-auto px-4 sm:px-8 lg:px-12 py-4 flex items-center justify-between gap-4">

          {/* Back button */}
          <button
            id="all-projects-back-btn"
            onClick={onBack}
            className="flex items-center gap-2 text-xs sm:text-sm font-semibold uppercase tracking-[0.15em] text-neutral-300 hover:text-white transition-colors group"
          >
            <ChevronLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
            <span>Back to Projects</span>
          </button>

          {/* Section label */}
          <div className="hidden sm:flex items-center gap-3">
            <span className="text-xs font-semibold uppercase tracking-[0.2em] text-white border-b border-white pb-0.5">
              04 — Completed Projects
            </span>
            <span className="text-neutral-500 text-xs">•</span>
            <span className="text-neutral-400 text-xs tracking-wider uppercase">
              All {PROJECTS.length} Projects
            </span>
          </div>

          {/* Mobile count */}
          <span className="sm:hidden text-xs text-neutral-400 font-light">
            {filteredProjects.length} projects
          </span>
        </div>
      </header>

      {/* ── PAGE BODY ── */}
      <main className="max-w-[1520px] mx-auto px-4 sm:px-8 lg:px-12 pb-20 pt-8">

        {/* Page headline */}
        <div className="mb-8">
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-white leading-tight mb-2">
            ALL COMPLETED PROJECTS
          </h1>
          <p className="text-xs sm:text-sm text-neutral-400 font-light max-w-2xl">
            Every project delivered with precision, craftsmanship and attention to detail —
            from architectural facades to turnkey infrastructure.
          </p>
        </div>

        {/* ── CATEGORY FILTER PILLS ── */}
        <div className="flex flex-wrap gap-2 mb-8">
          {CATEGORIES.map((cat) => {
            const count =
              cat === 'ALL'
                ? PROJECTS.length
                : PROJECTS.filter((p) => p.categories.includes(cat)).length;
            const isActive = activeCategory === cat;
            return (
              <button
                key={cat}
                id={`filter-${cat.toLowerCase()}`}
                onClick={() => setActiveCategory(cat)}
                className={`px-3.5 py-1.5 rounded-full text-[11px] sm:text-xs font-semibold uppercase tracking-[0.14em] transition-all border ${
                  isActive
                    ? 'bg-white text-black border-white shadow-md'
                    : 'bg-white/[0.04] text-neutral-300 border-white/15 hover:bg-white/10 hover:border-white/30 hover:text-white'
                }`}
              >
                {cat}
                <span className={`ml-1.5 text-[10px] font-normal ${isActive ? 'text-black/50' : 'text-neutral-500'}`}>
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        {/* ── PROJECT GRID ── */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-5">
          {filteredProjects.map((project, idx) => (
            <div
              key={project.id}
              id={`project-card-${project.id}`}
              className="group relative rounded-2xl border border-white/10 bg-neutral-950/80 overflow-hidden hover:border-white/30 transition-all duration-500 hover:shadow-[0_8px_40px_rgba(0,0,0,0.8)] flex flex-col"
              style={{ animationDelay: `${Math.min(idx * 0.04, 0.6)}s` }}
            >
              {/* Project image */}
              <div className="relative w-full overflow-hidden" style={{ aspectRatio: '4/3' }}>
                <img
                  src={project.image}
                  alt={project.name}
                  loading="lazy"
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                {/* Gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent opacity-60 group-hover:opacity-80 transition-opacity duration-500" />

                {/* Category badges */}
                <div className="absolute top-3 left-3 flex flex-wrap gap-1.5">
                  {project.categories
                    .filter((c) => c !== 'ALL')
                    .slice(0, 2)
                    .map((cat) => (
                      <span
                        key={cat}
                        className="text-[9px] font-semibold uppercase tracking-[0.15em] bg-black/60 backdrop-blur-sm text-neutral-200 px-2 py-0.5 rounded-full border border-white/10"
                      >
                        {cat}
                      </span>
                    ))}
                </div>
              </div>

              {/* Card body */}
              <div className="flex flex-col flex-1 p-4 sm:p-5">
                {/* Type */}
                <p className="text-[10px] text-neutral-500 uppercase tracking-[0.18em] font-medium mb-1.5 leading-none">
                  {project.type}
                </p>

                {/* Name */}
                <h3 className="text-sm sm:text-[15px] font-bold text-white tracking-tight leading-snug mb-2 flex-1 line-clamp-2">
                  {project.name}
                </h3>

                {/* Description */}
                {project.description && (
                  <p className="text-[11px] sm:text-xs text-neutral-400 font-light leading-relaxed line-clamp-2 mt-auto pt-2 border-t border-white/[0.06]">
                    {project.description}
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Empty state */}
        {filteredProjects.length === 0 && (
          <div className="text-center py-24 text-neutral-500">
            <p className="text-sm font-light">No projects in this category.</p>
          </div>
        )}

        {/* ── BOTTOM BACK BUTTON ── */}
        <div className="mt-14 pt-8 border-t border-white/10 flex justify-start">
          <button
            id="all-projects-bottom-back-btn"
            onClick={onBack}
            className="flex items-center gap-2.5 text-xs sm:text-sm font-semibold uppercase tracking-[0.15em] text-neutral-300 hover:text-white transition-colors group"
          >
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
            <span>Back to Projects</span>
          </button>
        </div>
      </main>
    </div>
  );
};
