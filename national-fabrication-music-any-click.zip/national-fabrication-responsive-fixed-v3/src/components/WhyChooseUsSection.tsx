import React from 'react';
import {
  Calendar,
  ChevronRight,
  ShieldCheck,
  Wrench,
  Building2,
  Building,
  Bus,
  Train,
  GraduationCap,
  Landmark,
  Radio,
  MoreHorizontal,
  AppWindow,
  Volume2,
  Hash,
  Layers,
} from 'lucide-react';
import { useLetterReveal } from '../hooks/useLetterReveal';

interface WhyChooseUsSectionProps {
  onOpenContact?: () => void;
  onExploreProjects?: () => void;
}

const SOLUTIONS_LIST = [
  { icon: Layers, label: 'Interior Work' },
  { icon: Hash, label: 'Exterior Work' },
  { icon: AppWindow, label: 'Aluminium Doors & Windows' },
  { icon: Volume2, label: 'Soundproof Windows' },
  { icon: Wrench, label: 'Turnkey Project Execution' },
];

const TRUSTED_CLIENTS = [
  {
    icon: Building2,
    name: 'NCC',
    sub: 'NCC Limited',
  },
  {
    icon: Bus,
    name: 'KSRTC',
    sub: 'Karnataka RTC',
  },
  {
    icon: Radio,
    name: 'KPTCL',
    sub: 'Power Corp',
  },
  {
    icon: Building,
    name: 'Rami Reddy',
    sub: 'Construction',
  },
  {
    icon: Train,
    name: 'Indian Railways',
    sub: 'Infrastructure',
    highlight: true,
  },
  {
    icon: GraduationCap,
    name: 'Shri Krishna',
    sub: 'Institute of Tech',
  },
  {
    icon: Landmark,
    name: 'Apex Bank',
    sub: 'Apex State Bank',
  },
  {
    icon: MoreHorizontal,
    name: 'and many more',
    sub: 'Pan-India',
  },
];

export const WhyChooseUsSection: React.FC<WhyChooseUsSectionProps> = ({
  onOpenContact,
  onExploreProjects,
}) => {
  const titleRevealRef = useLetterReveal<HTMLHeadingElement>({ delay: 0.1 });

  return (
    <section
      id="why-choose-us"
      className="relative w-full bg-[#080808] text-white py-14 sm:py-20 lg:py-24 select-none overflow-hidden border-t border-white/10"
    >
      {/* Controlled subtle architectural backdrop tone matching Hero's dark aesthetic */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_70%_50%_at_50%_40%,rgba(255,255,255,0.025),transparent_75%)] pointer-events-none -z-10" />

      <div className="relative z-10 w-full max-w-[1520px] mx-auto px-4 sm:px-6 lg:px-12">
        
        {/* ===================== SECTION HEADER ===================== */}
        <div className="text-center max-w-4xl mx-auto mb-10 sm:mb-14">
          <div className="flex items-center justify-center gap-3 mb-3">
            <span className="text-xs sm:text-sm font-semibold uppercase tracking-[0.25em] text-white border-b border-white pb-0.5">
              03 — Why Choose Us
            </span>
          </div>

          <div className="text-xs sm:text-sm font-semibold uppercase tracking-[0.25em] text-neutral-400 mb-2">
            WHY CHOOSE
          </div>

          <h2 ref={titleRevealRef} className="text-3xl sm:text-5xl lg:text-[54px] font-bold tracking-[-0.03em] metallic-text leading-tight sm:leading-none mb-3">
            NATIONAL FABRICATION?
          </h2>

          <p className="text-[10.5px] sm:text-xs lg:text-[13px] font-medium tracking-[0.18em] uppercase text-neutral-400 max-w-2xl mx-auto leading-relaxed">
            Experience. Quality. Execution. Built for a better tomorrow.
          </p>

          <div className="w-12 h-[1.5px] bg-white/40 mx-auto mt-4 rounded-full" />
        </div>

        {/* ===================== BENTO GRID CONTAINER ===================== */}
        <div className="space-y-4 sm:space-y-6">
          
          {/* ===================== TOP ROW: 3 CARDS ===================== */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            
            {/* ---------------- CARD 01: Proven Experience ---------------- */}
            <div className="relative rounded-2xl sm:rounded-3xl border border-white/15 bg-neutral-950/80 backdrop-blur-md overflow-hidden p-6 sm:p-7 flex flex-col justify-between group hover:border-white/35 transition-all shadow-xl min-h-[380px]">
              {/* Background architectural image on right */}
              <div className="absolute right-0 top-0 bottom-0 w-3/5 sm:w-1/2 pointer-events-none overflow-hidden opacity-35 group-hover:opacity-45 transition-opacity duration-700">
                <img
                  src="https://res.cloudinary.com/p8mbdjxv/image/upload/v1791151266/Gemini_Generated_Image_62o97862o97862o9.png"
                  alt="Modern architectural glass facade"
                  className="w-full h-full object-cover scale-105 group-hover:scale-110 transition-transform duration-1000"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-neutral-950 via-neutral-950/80 to-transparent" />
                <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-transparent to-neutral-950/40" />
              </div>

              {/* Text content */}
              <div className="relative z-10">
                <div className="text-xs sm:text-sm font-semibold text-neutral-400 tracking-wider mb-3">
                  01
                </div>
                <h3 className="text-xl sm:text-2xl font-bold tracking-tight text-white leading-tight mb-2.5">
                  Proven
                  <br />
                  Experience
                </h3>
                <p className="text-xs sm:text-[13px] text-neutral-300 font-light leading-relaxed max-w-[270px]">
                  25+ years of delivering high-quality fabrication solutions across commercial, institutional, residential and infrastructure projects.
                </p>
              </div>

              {/* Bottom Stat Pill matching reference */}
              <div className="relative z-10 mt-6 pt-4 border-t border-white/10 flex items-center gap-3">
                <div className="rounded-xl border border-white/15 bg-white/[0.04] backdrop-blur-md px-3.5 py-2.5 flex items-center gap-3 shadow-md w-full">
                  <div className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center shrink-0">
                    <Calendar className="w-4 h-4 text-neutral-300" />
                  </div>
                  <div>
                    <div className="text-lg sm:text-xl font-bold text-white tracking-tight leading-none">
                      25+
                    </div>
                    <div className="text-[9px] uppercase tracking-wider text-neutral-400 mt-0.5 font-medium">
                      Years of Experience
                    </div>
                  </div>

                  <div className="w-px h-8 bg-white/15 mx-1" />

                  <div>
                    <div className="text-[9px] uppercase tracking-wider text-neutral-400 font-medium">
                      Since
                    </div>
                    <div className="text-lg sm:text-xl font-bold text-white tracking-tight leading-none mt-0.5">
                      2004
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* ---------------- CARD 02: End-to-End Solutions ---------------- */}
            <div className="relative rounded-2xl sm:rounded-3xl border border-white/15 bg-neutral-950/80 backdrop-blur-md overflow-hidden p-6 sm:p-7 flex flex-col justify-between group hover:border-white/35 transition-all shadow-xl min-h-[380px]">
              {/* Background architectural glass facade */}
              <div className="absolute right-0 top-0 bottom-0 w-2/5 pointer-events-none overflow-hidden opacity-30 group-hover:opacity-40 transition-opacity duration-700">
                <img
                  src="https://res.cloudinary.com/p8mbdjxv/image/upload/v1791151262/Gemini_Generated_Image_pew9b4pew9b4pew9.png"
                  alt="Architectural structure"
                  className="w-full h-full object-cover scale-105 group-hover:scale-110 transition-transform duration-1000"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-neutral-950 via-neutral-950/85 to-transparent" />
                <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-transparent to-neutral-950/40" />
              </div>

              {/* Text content */}
              <div className="relative z-10">
                <div className="text-xs sm:text-sm font-semibold text-neutral-400 tracking-wider mb-3">
                  02
                </div>
                <h3 className="text-xl sm:text-2xl font-bold tracking-tight text-white leading-tight mb-2.5">
                  End-to-End
                  <br />
                  <span className="text-neutral-200">Solutions</span>
                </h3>
                <p className="text-xs sm:text-[13px] text-neutral-300 font-light leading-relaxed mb-4">
                  From concept to completion, we provide complete fabrication solutions for interiors, exteriors and turnkey projects.
                </p>

                {/* Solutions List matching reference */}
                <div className="space-y-1.5">
                  {SOLUTIONS_LIST.map((sol) => {
                    const IconComp = sol.icon;
                    return (
                      <div
                        key={sol.label}
                        onClick={onExploreProjects}
                        className="flex items-center justify-between px-3 py-1.5 rounded-lg border border-white/10 bg-white/[0.02] hover:bg-white/[0.07] hover:border-white/25 transition-all text-xs text-neutral-200 cursor-pointer group/item"
                      >
                        <div className="flex items-center gap-2.5">
                          <IconComp className="w-3.5 h-3.5 text-neutral-400 group-hover/item:text-white transition-colors" />
                          <span className="tracking-tight text-[11.5px] sm:text-xs">{sol.label}</span>
                        </div>
                        <ChevronRight className="w-3.5 h-3.5 text-neutral-500 group-hover/item:text-white group-hover/item:translate-x-0.5 transition-all" />
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* ---------------- CARD 03: Quality & Craftsmanship ---------------- */}
            <div className="relative rounded-2xl sm:rounded-3xl border border-white/15 bg-neutral-950/80 backdrop-blur-md overflow-hidden p-6 sm:p-7 flex flex-col justify-between group hover:border-white/35 transition-all shadow-xl min-h-[380px] md:col-span-2 lg:col-span-1">
              {/* Background architectural steel framework */}
              <div className="absolute right-0 top-0 bottom-0 w-3/5 sm:w-1/2 pointer-events-none overflow-hidden opacity-30 group-hover:opacity-40 transition-opacity duration-700">
                <img
                  src="https://res.cloudinary.com/p8mbdjxv/image/upload/v1791151248/Gemini_Generated_Image_6hsg1w6hsg1w6hsg.png"
                  alt="Industrial steel joints"
                  className="w-full h-full object-cover scale-105 group-hover:scale-110 transition-transform duration-1000"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-neutral-950 via-neutral-950/85 to-transparent" />
                <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-transparent to-neutral-950/40" />
              </div>

              {/* Text content */}
              <div className="relative z-10">
                <div className="text-xs sm:text-sm font-semibold text-neutral-400 tracking-wider mb-3">
                  03
                </div>
                <h3 className="text-xl sm:text-2xl font-bold tracking-tight text-white leading-tight mb-2.5">
                  Quality &
                  <br />
                  Craftsmanship
                </h3>
                <p className="text-xs sm:text-[13px] text-neutral-300 font-light leading-relaxed max-w-[270px]">
                  We combine precision engineering, premium materials and skilled workmanship to deliver durable and aesthetic solutions for every project.
                </p>
              </div>

              {/* Badges container matching reference */}
              <div className="relative z-10 mt-6 pt-4 border-t border-white/10 grid grid-cols-2 gap-2.5">
                <div className="rounded-xl border border-white/15 bg-white/[0.03] backdrop-blur-md p-3 flex flex-col sm:flex-row items-center sm:items-start text-center sm:text-left gap-2 shadow-sm">
                  <div className="w-7 h-7 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center shrink-0">
                    <ShieldCheck className="w-4 h-4 text-neutral-300" />
                  </div>
                  <div>
                    <div className="text-[10px] sm:text-[11px] font-semibold uppercase tracking-wider text-white">
                      Premium
                    </div>
                    <div className="text-[9px] uppercase tracking-wider text-neutral-400">
                      Materials
                    </div>
                  </div>
                </div>

                <div className="rounded-xl border border-white/15 bg-white/[0.03] backdrop-blur-md p-3 flex flex-col sm:flex-row items-center sm:items-start text-center sm:text-left gap-2 shadow-sm">
                  <div className="w-7 h-7 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center shrink-0">
                    <Wrench className="w-4 h-4 text-neutral-300" />
                  </div>
                  <div>
                    <div className="text-[10px] sm:text-[11px] font-semibold uppercase tracking-wider text-white">
                      High
                    </div>
                    <div className="text-[9px] uppercase tracking-wider text-neutral-400">
                      Craftsmanship
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>

          {/* ===================== BOTTOM ROW: 2 ASYMMETRIC CARDS ===================== */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 sm:gap-6">
            
            {/* ---------------- CARD 04: Landmark Project (Terminal) ---------------- */}
            <div className="lg:col-span-7 rounded-2xl sm:rounded-3xl border border-white/15 bg-neutral-950/85 backdrop-blur-md overflow-hidden relative group hover:border-white/35 transition-all shadow-xl min-h-[340px] flex flex-col justify-between p-6 sm:p-8">
              
              {/* Landmark Terminal Image dominating the right & background */}
              <div className="absolute right-0 top-0 bottom-0 w-3/5 sm:w-2/3 pointer-events-none overflow-hidden">
                <img
                  src="https://res.cloudinary.com/p8mbdjxv/image/upload/v1791151270/Gemini_Generated_Image_u1xw4gu1xw4gu1xw.png"
                  alt="Sir M. Visvesvaraya Terminal Baiyappanahalli Bengaluru"
                  className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-neutral-950 via-neutral-950/90 via-35% to-black/20" />
                <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-transparent to-neutral-950/30" />
              </div>

              {/* Text details on left */}
              <div className="relative z-10 max-w-md">
                <div className="text-[10px] sm:text-xs font-semibold tracking-[0.22em] text-neutral-400 uppercase mb-2">
                  LANDMARK PROJECT
                </div>

                <h3 className="text-xl sm:text-2xl lg:text-3xl font-bold tracking-tight text-white leading-tight mb-1">
                  Sir M. Visvesvaraya Terminal
                </h3>

                <div className="text-xs sm:text-sm text-neutral-300 font-light mb-3">
                  Baiyappanahalli, Bengaluru
                </div>

                <p className="text-xs sm:text-[13px] text-neutral-300 font-light leading-relaxed">
                  National Fabrication was part of this landmark railway infrastructure project at Baiyappanahalli, Bengaluru, under contractor M. V. Satyanarayana.
                </p>
              </div>

              {/* Bottom feature note */}
              <div className="relative z-10 pt-4 border-t border-white/10 text-[11px] text-neutral-400 font-light">
                <span>High-span structural steel framing, canopy framework & architectural glazing</span>
              </div>

            </div>

            {/* ---------------- CARD 05: Trusted by Leading Organizations ---------------- */}
            <div className="lg:col-span-5 rounded-2xl sm:rounded-3xl border border-white/15 bg-neutral-950/85 backdrop-blur-md overflow-hidden p-6 sm:p-7 flex flex-col justify-between group hover:border-white/35 transition-all shadow-xl min-h-[340px]">
              
              <div>
                <h3 className="text-xl sm:text-2xl font-bold tracking-tight text-white leading-tight mb-1">
                  Trusted by Leading <span className="text-neutral-300">Organizations</span>
                </h3>
                <p className="text-xs sm:text-[13px] text-neutral-400 font-light leading-relaxed mb-5">
                  Our work is trusted by reputed clients across multiple sectors.
                </p>

                {/* 4 x 2 Grid of Client Tiles */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-2.5">
                  {TRUSTED_CLIENTS.map((client) => {
                    const IconComp = client.icon;
                    return (
                      <div
                        key={client.name}
                        className={`rounded-xl border p-2.5 sm:p-3 flex flex-col items-center text-center justify-center transition-all ${
                          client.highlight
                            ? 'border-white/30 bg-white/[0.05] text-white shadow-sm'
                            : 'border-white/10 bg-white/[0.02] text-neutral-300 hover:border-white/25 hover:bg-white/[0.05] hover:text-white'
                        }`}
                      >
                        <div className="w-7 h-7 rounded-full bg-white/5 border border-white/10 flex items-center justify-center mb-1.5 shrink-0">
                          <IconComp className="w-3.5 h-3.5 text-neutral-300" />
                        </div>
                        <div className="text-[11px] sm:text-xs font-semibold text-white tracking-tight leading-tight">
                          {client.name}
                        </div>
                        {client.sub && (
                          <div className="text-[9px] text-neutral-400 font-light leading-tight mt-0.5 truncate max-w-full">
                            {client.sub}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Bottom subtle note */}
              <div className="pt-4 mt-3 border-t border-white/10 flex items-center justify-between text-[11px] text-neutral-400 font-light">
                <span>Verified corporate & infrastructure executions</span>
                <span>Pan-India client partnerships</span>
              </div>

            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
