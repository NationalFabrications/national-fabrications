import React, { useState, useEffect, useRef } from 'react';
import { ArrowUpRight, X, Check, Mail, MapPin, Send, Building2, ShieldCheck, Award, Layers, Volume2, VolumeX } from 'lucide-react';


import { Logo } from './components/Logo';
import { ClientLogos } from './components/ClientLogos';
import { WhyChooseUsSection } from './components/WhyChooseUsSection';
import { AboutUsSection } from './components/AboutUsSection';
import { ProjectsSection } from './components/ProjectsSection';
import { ContactSection } from './components/ContactSection';
import { AllProjectsPage } from './components/AllProjectsPage';
import { useLetterReveal } from './hooks/useLetterReveal';

export default function App() {
  // Hero text reveal: starts after the required 3-second cinematic lead-in,
  // then reveals each text group left-to-right with a deliberately slow, premium stagger.
  const heroEyebrowLeftRef = useLetterReveal<HTMLDivElement>({ delay: 3.0 });
  const heroEyebrowRightRef = useLetterReveal<HTMLDivElement>({ delay: 3.25 });
  const heroYearsRef = useLetterReveal<HTMLDivElement>({ delay: 3.5 });
  const heroLine1Ref = useLetterReveal<HTMLSpanElement>({ delay: 3.0, perLetter: 0.12, minDuration: 2.4, maxDuration: 3.2 });
  const heroLine2Ref = useLetterReveal<HTMLSpanElement>({ delay: 3.45, perLetter: 0.12, minDuration: 2.4, maxDuration: 3.2 });
  const heroTaglineRef = useLetterReveal<HTMLHeadingElement>({ delay: 4.1, perLetter: 0.11, minDuration: 2.4, maxDuration: 3.6 });
  const heroDescriptionRef = useLetterReveal<HTMLParagraphElement>({ delay: 4.7, perLetter: 0.09, minDuration: 2.5, maxDuration: 4.0 });
  const heroCtaRef = useLetterReveal<HTMLSpanElement>({ delay: 5.35, perLetter: 0.1, minDuration: 2.4, maxDuration: 3.4 });
  const heroStatsRef = useLetterReveal<HTMLDivElement>({ delay: 5.85, perLetter: 0.09, minDuration: 2.4, maxDuration: 4.0 });
  const [activeModal, setActiveModal] = useState<'contact' | 'portfolio' | 'about' | null>(null);
  const [quoteSubmitted, setQuoteSubmitted] = useState(false);
  const [scrollY, setScrollY] = useState(0);
  const [showAllProjects, setShowAllProjects] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    projectType: 'Commercial Turnkey',
    message: ''
  });
  const [isMuted, setIsMuted] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const hasStartedRef = useRef(false);
  const startedFromFirstInteractionRef = useRef(false);

  // Keep one real <audio> element mounted for the lifetime of the page.
  // Browsers may reject audible autoplay; in that case the first user
  // interaction (or the existing volume button) starts this same element.
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    audio.loop = false;
    audio.volume = 1;
    audio.muted = false;
    audio.preload = 'auto';

    const markEnded = () => {
      hasStartedRef.current = true;
    };
    audio.addEventListener('ended', markEnded);

    console.log('Audio initialized:', audio.src);
    console.log('Attempting audio playback');
    audio.play().then(() => {
      hasStartedRef.current = true;
      console.log('Audio playback started');
    }).catch((error) => {
      // Audible autoplay is commonly blocked until the user interacts.
      console.error('Audio playback failed:', error);
    });

    return () => audio.removeEventListener('ended', markEnded);
  }, []);

  // If autoplay is blocked, start the SAME audio element on the first
  // genuine user interaction anywhere on the page. Capture phase ensures
  // this happens before a button's click handler can toggle/mute it.
  useEffect(() => {
    const startFromInteraction = () => {
      const audio = audioRef.current;
      if (!audio || hasStartedRef.current || audio.ended || !audio.paused) return;

      audio.muted = false;
      audio.volume = 1;
      console.log('Starting audio from first user interaction');
      startedFromFirstInteractionRef.current = true;
      audio.play().then(() => {
        hasStartedRef.current = true;
        setIsMuted(false);
        console.log('Audio started successfully from first user interaction');
      }).catch((error) => {
        console.error('First interaction audio error:', error);
      });
    };

    window.addEventListener('pointerdown', startFromInteraction, { capture: true });
    return () => window.removeEventListener('pointerdown', startFromInteraction, { capture: true });
  }, []);

  React.useEffect(() => {
    let ticking = false;
    const onScroll = () => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          if (window.scrollY < 900) {
            setScrollY(window.scrollY);
          }
          ticking = false;
        });
        ticking = true;
      }
    };

    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const toggleMute = () => {
    console.log('VOLUME BUTTON CLICKED');
    const audio = audioRef.current;
    if (!audio || audio.ended) return;

    // The global pointerdown handler may have started playback immediately
    // before this button's click event. Do not mute it on that same click.
    if (startedFromFirstInteractionRef.current) {
      startedFromFirstInteractionRef.current = false;
      return;
    }

    // If autoplay was blocked, this click is a user gesture. Start the same
    // audio element directly from the click handler.
    if (!hasStartedRef.current || audio.paused) {
      audio.muted = false;
      audio.volume = 1;
      console.log('Starting audio from user interaction');
      audio.play().then(() => {
        hasStartedRef.current = true;
        setIsMuted(false);
        console.log('Audio started successfully from user interaction');
      }).catch((error) => {
        console.error('Volume button audio error:', error);
      });
      return;
    }

    audio.muted = !audio.muted;
    setIsMuted(audio.muted);
  };

  // Subtle scroll parallax factor for hero text
  const scrollRatio = Math.min(scrollY / 550, 1);
  const headlineScrollY = -40 * scrollRatio;
  const descScrollY = -25 * scrollRatio;
  const heroTextOpacity = Math.max(1 - scrollRatio * 1.3, 0);

  const scrollToWhyChooseUs = () => {
    const el = document.getElementById('why-choose-us');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToAbout = () => {
    const el = document.getElementById('about');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToProjects = () => {
    const el = document.getElementById('completed-projects');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToContact = () => {
    const el = document.getElementById('contact');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToHome = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleQuoteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setQuoteSubmitted(true);
    setTimeout(() => {
      setQuoteSubmitted(false);
      setActiveModal(null);
      setFormData({ name: '', phone: '', projectType: 'Commercial Turnkey', message: '' });
    }, 2400);
  };

  return (
    <div className="min-h-screen bg-[#080808] text-white selection:bg-white selection:text-black font-sans">
      
      {/* One persistent audio element; playback is controlled by the existing volume button. */}
      <audio ref={audioRef} src="/audio/music.mp3" preload="auto" autoPlay loop={false} playsInline aria-hidden="true" />

      {/* Global Volume Control */}
      <button 
        onClick={toggleMute}
        className="fixed bottom-6 right-6 z-50 w-11 h-11 rounded-full bg-neutral-900 border border-white/20 flex items-center justify-center text-white hover:bg-neutral-800 transition-colors shadow-2xl cursor-pointer"
        aria-label="Toggle Sound"
      >
        {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
      </button>
      {/* ===================== HERO SECTION ===================== */}
      <section className="hero-section relative min-h-screen w-full flex flex-col justify-between overflow-x-clip overflow-y-hidden text-white">
        
        {/* Hero Background Video (Strictly confined ONLY to the Hero section) */}
        <div className="absolute inset-0 w-full h-full overflow-hidden pointer-events-none z-0">
          <video
            autoPlay
            loop
            muted
            playsInline
            className="w-full h-full object-cover scale-105"
            src="https://res.cloudinary.com/p8mbdjxv/video/upload/v1791148839/Modern_apartment_building_pans_r__20261005020156.mp4"
          />
          {/* Subtle cinematic gradient to preserve text legibility while keeping the video clear */}
          <div className="absolute inset-0 bg-black/30 bg-gradient-to-b from-black/40 via-transparent to-black/60 pointer-events-none" />
        </div>

        {/* ===================== TOP HEADER ===================== */}
      <header className="relative z-20 w-full max-w-[1520px] mx-auto px-4 sm:px-6 lg:px-12 pt-3 sm:pt-6 pb-2">
        
        {/* MOBILE HEADER (< lg): Completely separate centered logo with dedicated navigation row */}
        <div className="flex flex-col items-center lg:hidden w-full gap-3 pt-1 pb-1">
          {/* Row 1: Logo completely separate, perfectly centered, no interference */}
          <div className="flex justify-center items-center py-1">
            <Logo />
          </div>

          {/* Row 2: Navigation Pills & Phone Contact Button */}
          <div className="w-full flex flex-wrap items-center justify-center gap-2 pt-1 pb-1">
            <nav className="flex flex-wrap items-center justify-center gap-1.5 sm:gap-2">
              <button
                onClick={scrollToHome}
                className="bg-white text-black font-semibold text-xs px-3.5 sm:px-5 py-1.5 sm:py-2 rounded-full shadow-sm hover:bg-neutral-200 transition-all cursor-pointer"
              >
                Home
              </button>
              <button
                onClick={scrollToAbout}
                className="border border-white/35 hover:border-white text-white font-normal text-xs px-3 sm:px-4 py-1.5 sm:py-2 rounded-full hover:bg-white/10 transition-all cursor-pointer whitespace-nowrap"
              >
                About Us
              </button>
              <button
                onClick={scrollToWhyChooseUs}
                className="border border-white/35 hover:border-white text-white font-normal text-xs px-3 sm:px-4 py-1.5 sm:py-2 rounded-full hover:bg-white/10 transition-all cursor-pointer whitespace-nowrap"
              >
                Why Choose Us
              </button>
              <button
                onClick={scrollToProjects}
                className="border border-white/35 hover:border-white text-white font-normal text-xs px-3 sm:px-4 py-1.5 sm:py-2 rounded-full hover:bg-white/10 transition-all cursor-pointer whitespace-nowrap"
              >
                Projects
              </button>
              <button
                onClick={scrollToContact}
                className="border border-white/35 hover:border-white text-white font-normal text-xs px-3 sm:px-4 py-1.5 sm:py-2 rounded-full hover:bg-white/10 transition-all cursor-pointer whitespace-nowrap"
              >
                Contact Us
              </button>
            </nav>

          </div>
        </div>

        {/* DESKTOP HEADER (>= lg): 3-column layout (Nav - Centered Logo - Action Button) */}
        <div className="hidden lg:grid lg:grid-cols-3 items-center w-full">
          
          {/* Left Nav Pills */}
          <nav className="flex items-center gap-2 justify-start">
            <button
              onClick={scrollToHome}
              className="bg-white text-black font-semibold text-sm px-5 py-2.5 rounded-full shadow-sm hover:bg-neutral-200 transition-all cursor-pointer"
            >
              Home
            </button>
            <button
              onClick={scrollToAbout}
              className="border border-white/35 hover:border-white text-white font-normal text-sm px-4 py-2.5 rounded-full hover:bg-white/10 transition-all cursor-pointer whitespace-nowrap"
            >
              About Us
            </button>
            <button
              onClick={scrollToWhyChooseUs}
              className="border border-white/35 hover:border-white text-white font-normal text-sm px-4 py-2.5 rounded-full hover:bg-white/10 transition-all cursor-pointer whitespace-nowrap"
            >
              Why Choose Us
            </button>
            <button
              onClick={scrollToProjects}
              className="border border-white/35 hover:border-white text-white font-normal text-sm px-4 py-2.5 rounded-full hover:bg-white/10 transition-all cursor-pointer whitespace-nowrap"
            >
              Projects
            </button>
            <button
              onClick={scrollToContact}
              className="border border-white/35 hover:border-white text-white font-normal text-sm px-4 py-2.5 rounded-full hover:bg-white/10 transition-all cursor-pointer whitespace-nowrap"
            >
              Contact Us
            </button>
          </nav>

          {/* Center Brand Logo */}
          <div className="flex justify-center items-center">
            <Logo />
          </div>

          {/* Right Action Button */}
          <div className="flex items-center justify-end">
            <button
              onClick={scrollToContact}
              className="bg-white text-black font-semibold text-sm px-6 py-2.5 rounded-full flex items-center gap-2 hover:bg-neutral-200 transition-all shadow-md group cursor-pointer"
            >
              <span>Get in Touch</span>
              <ArrowUpRight className="w-4 h-4 text-black group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </button>
          </div>

        </div>
      </header>

      {/* ===================== HERO MAIN STAGE ===================== */}
      <main className="relative z-10 w-full min-w-0 px-4 sm:px-6 lg:px-12 flex-1 flex flex-col justify-center pt-2 sm:pt-4 pb-6">
        
        {/* Accent Markers & Giant Typography Area */}
        <div
          className="relative w-full"
          style={{
            transform: `translate3d(0, ${headlineScrollY}px, 0)`,
            opacity: heroTextOpacity,
            transition: 'opacity 0.1s linear',
          }}
        >
          
          {/* Top Left Marker: Since 2004 */}
          <div ref={heroEyebrowLeftRef} className="hero-anim-eyebrow absolute left-0 top-3 sm:top-4 z-10 border-l border-white/40 pl-2.5 sm:pl-3 select-none">
            <div className="text-[11px] sm:text-xs text-neutral-300 font-light leading-tight">Since</div>
            <div className="text-[11px] sm:text-xs text-white font-medium">2004</div>
            {/* Subtle Expanding Architectural Horizontal Line */}
            <div className="hero-anim-line h-[1px] bg-gradient-to-r from-white/45 via-white/20 to-transparent mt-1.5" />
          </div>

          {/* Top Right Marker: Design / Fabricate / Deliver */}
          <div ref={heroEyebrowRightRef} className="hero-anim-eyebrow absolute right-0 top-3 sm:top-4 z-10 border-r border-white/40 pr-2.5 sm:pr-3 text-right select-none">
            <div className="text-[11px] sm:text-xs text-neutral-200 font-light leading-tight">Design</div>
            <div className="text-[11px] sm:text-xs text-neutral-200 font-light leading-tight">Fabricate</div>
            <div className="text-[11px] sm:text-xs text-neutral-200 font-light leading-tight">Deliver</div>
          </div>

          {/* Mid Left Marker: 25 Years of Excellence */}
          <div ref={heroYearsRef} className="hero-anim-eyebrow absolute left-0 top-[78px] sm:top-[110px] md:top-[160px] lg:top-[190px] z-10 border-l border-white/40 pl-2 sm:pl-3 select-none">
            <div className="text-[10px] sm:text-xs text-white font-medium leading-tight">25 Years</div>
            <div className="text-[10px] sm:text-xs text-neutral-400 font-light leading-tight">of Excellence</div>
          </div>

          {/* Massive Display Typography: National Fabrication with Masked Reveal */}
          <div className="hero-headline-stage relative w-full min-w-0 max-w-full pt-4 sm:pt-6 md:pt-8 lg:pt-6 pb-2 sm:pb-4 pl-10 sm:pl-14 md:pl-18 lg:pl-20 select-none overflow-hidden bg-transparent border-0 shadow-none rounded-none backdrop-blur-none">
            {/* Subtle Shimmer Light Sweep after Headline Settles */}
            <div className="hero-shimmer" aria-hidden="true" />

            <h1 className="w-full max-w-full min-w-0 font-bold tracking-[-0.04em] leading-[0.88] flex flex-col">
              {/* Line 1: National (Masked Viewport) */}
              <span className="w-full max-w-full min-w-0 overflow-hidden pb-1 -mb-1 block bg-transparent">
                <span ref={heroLine1Ref} className="w-full max-w-full min-w-0 overflow-hidden block bg-transparent">
                  <span className="block text-[clamp(2.75rem,13vw,13.125rem)] metallic-text font-bold">
                    National
                  </span>
                </span>
              </span>

              {/* Line 2: Fabrication (Masked Viewport) */}
              <span className="w-full max-w-full min-w-0 overflow-hidden pb-3 -mb-3 -mt-1 sm:-mt-3 md:-mt-6 lg:-mt-8 block bg-transparent">
                <span ref={heroLine2Ref} className="w-full max-w-full min-w-0 overflow-hidden block bg-transparent">
                  <span className="block text-[clamp(2.75rem,13vw,13.125rem)] metallic-text font-bold">
                    Fabrication
                  </span>
                </span>
              </span>
            </h1>
          </div>

        </div>

        {/* Lower Content Tier: Headline + Description, Explore Button, Stat Cards */}
        <div
          className="mt-4 sm:mt-6 md:mt-8 w-full min-w-0 grid grid-cols-1 lg:grid-cols-12 items-end gap-5 sm:gap-8 z-20"
          style={{
            transform: `translate3d(0, ${descScrollY}px, 0)`,
            opacity: heroTextOpacity,
            transition: 'opacity 0.1s linear',
          }}
        >
          
          {/* Left Text Block (5 columns on desktop) */}
          <div className="hero-anim-description lg:col-span-5 max-w-xl">
            <h2 ref={heroTaglineRef} className="text-xl sm:text-2xl lg:text-[26px] font-normal text-white tracking-tight leading-tight">
              Premium Interior & Exterior
              <br />
              Fabrication Solutions
            </h2>
            <p ref={heroDescriptionRef} className="text-xs sm:text-[14px] text-neutral-300 font-light leading-relaxed mt-2 sm:mt-3 max-w-lg">
              We design, fabricate and deliver modern spaces for IT companies, commercial shops, offices, homes, clubhouses and turnkey projects.
            </p>
          </div>

          {/* Center Explore Our Work CTA Button (3 columns on desktop) */}
          <div className="hero-anim-cta lg:col-span-3 flex items-center justify-start lg:justify-center">
            <button
              onClick={scrollToProjects}
              className="group w-full sm:w-auto justify-between sm:justify-start bg-white text-black font-semibold text-xs sm:text-sm pl-5 sm:pl-6 pr-2 sm:pr-2.5 py-2.5 rounded-full flex items-center gap-3 sm:gap-3.5 hover:bg-neutral-100 hover:scale-[1.02] active:scale-[0.98] transition-all shadow-2xl cursor-pointer"
            >
              <span ref={heroCtaRef} className="tracking-tight text-neutral-950 font-medium">Explore Our Work</span>
              <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-black flex items-center justify-center text-white transition-transform group-hover:rotate-45 group-hover:bg-neutral-800 shrink-0">
                <ArrowUpRight className="w-4 h-4 text-white stroke-[2.2]" />
              </div>
            </button>
          </div>

          {/* Right Stat Cards (4 columns on desktop, stacked on right, overlapping lower typography) */}
          <div ref={heroStatsRef} className="hero-anim-stats lg:col-span-4 flex flex-row lg:flex-col items-stretch lg:items-end gap-3 lg:-mt-24 xl:-mt-32">
            {/* Card 1: 25+ */}
            <div className="flex-1 lg:flex-none w-full sm:w-[210px] lg:w-[230px] rounded-2xl border border-white/20 bg-neutral-950/85 backdrop-blur-md p-3.5 sm:p-5 transition-all hover:border-white/40 hover:bg-neutral-900/90 shadow-2xl">
              <div className="text-2xl sm:text-4xl xl:text-[42px] font-bold text-white tracking-tight leading-none">
                25+
              </div>
              <div className="text-[10px] sm:text-xs text-neutral-300 mt-1.5 sm:mt-2 leading-snug">
                Years of Experience
                <br />
                <span className="text-neutral-400">in Fabrication & Design</span>
              </div>
            </div>

            {/* Card 2: 2,000+ */}
            <div className="flex-1 lg:flex-none w-full sm:w-[210px] lg:w-[230px] rounded-2xl border border-white/20 bg-neutral-950/85 backdrop-blur-md p-3.5 sm:p-5 transition-all hover:border-white/40 hover:bg-neutral-900/90 shadow-2xl">
              <div className="text-2xl sm:text-4xl xl:text-[42px] font-bold text-white tracking-tight leading-none">
                2,000+
              </div>
              <div className="text-[10px] sm:text-xs text-neutral-300 mt-1.5 sm:mt-2 leading-snug">
                Completed Projects
                <br />
                <span className="text-neutral-400">Across India</span>
              </div>
            </div>
          </div>

        </div>

      </main>

      {/* ===================== FOOTER CLIENT LOGOS ===================== */}
      <footer className="relative z-20 w-full max-w-[1520px] mx-auto px-4 sm:px-6 lg:px-12 pt-4 pb-6 sm:pb-8">
        <ClientLogos />
      </footer>

      </section>

      {/* ===================== SECTION 2 — ABOUT US ===================== */}
      <AboutUsSection onOpenContact={scrollToContact} />

      {/* ===================== SECTION 3 — WHY CHOOSE US ===================== */}
      <WhyChooseUsSection
        onOpenContact={scrollToContact}
        onExploreProjects={scrollToProjects}
      />

      {/* ===================== SECTION 4 — COMPLETED PROJECTS (3D ORBIT EXPERIENCE) ===================== */}
      <ProjectsSection onViewAll={() => setShowAllProjects(true)} />

      {/* ===================== SECTION 5 — CONTACT US ===================== */}
      <ContactSection />

      {/* ===================== ARCHITECTURAL FOOTER ===================== */}
      <footer className="w-full bg-[#050505] border-t border-white/10 py-8 px-4 sm:px-6 lg:px-12 text-xs text-neutral-400 font-light select-none">
        <div className="max-w-[1520px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="text-white font-medium">National Fabrication</span>
            <span>•</span>
            <span className="text-neutral-400">Since 2004</span>
            <span>•</span>
            <span className="text-neutral-400">Jayanagar, Bangalore</span>
          </div>

          <div className="text-center text-neutral-400 text-[11px] sm:text-xs">
            © {new Date().getFullYear()} National Fabrication. All rights reserved. Precision Architectural Engineering.
          </div>

          <div className="flex items-center gap-4 text-neutral-400">
            <button
              onClick={scrollToHome}
              className="hover:text-white transition-colors cursor-pointer flex items-center gap-1 text-xs"
            >
              Back to Top ↑
            </button>
          </div>
        </div>
      </footer>

      {/* ===================== INTERACTIVE MODALS ===================== */}

      {/* 1. Contact / Get a Quote Modal */}
      {activeModal === 'contact' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="relative w-full max-w-lg bg-neutral-950 border border-white/20 rounded-3xl p-6 sm:p-8 text-white shadow-2xl">
            <button
              onClick={() => setActiveModal(null)}
              className="absolute top-5 right-5 w-8 h-8 rounded-full bg-neutral-900 border border-white/10 flex items-center justify-center hover:bg-neutral-800 transition-colors"
            >
              <X className="w-4 h-4 text-neutral-300" />
            </button>

            <div className="mb-6">
              <span className="text-xs uppercase tracking-widest text-neutral-400 font-semibold">Direct Consultation</span>
              <h3 className="text-2xl font-bold mt-1">Connect with National Fabrication</h3>
              <p className="text-sm text-neutral-400 mt-1">
                Reach out for turnkey architectural fabrication, metal glazing, IT fitouts, and heavy commercial solutions.
              </p>
            </div>

            {quoteSubmitted ? (
              <div className="py-12 flex flex-col items-center justify-center text-center">
                <div className="w-14 h-14 rounded-full bg-white text-black flex items-center justify-center mb-4">
                  <Check className="w-7 h-7 stroke-[3]" />
                </div>
                <h4 className="text-xl font-bold">Request Received</h4>
                <p className="text-sm text-neutral-400 mt-2 max-w-xs">
                  Our chief project engineer will contact you within 2 hours with project feasibility and consultation.
                </p>
              </div>
            ) : (
              <form onSubmit={handleQuoteSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">Your Name</label>
                  <input
                    required
                    type="text"
                    placeholder="Enter your name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full bg-neutral-900 border border-white/15 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-white transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">Phone Number</label>
                  <input
                    required
                    type="tel"
                    placeholder="+91 98451 13513"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full bg-neutral-900 border border-white/15 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-white transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">Project Category</label>
                  <select
                    value={formData.projectType}
                    onChange={(e) => setFormData({ ...formData, projectType: e.target.value })}
                    className="w-full bg-neutral-900 border border-white/15 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-white transition-colors"
                  >
                    <option value="Commercial Turnkey">Commercial & Retail Turnkey</option>
                    <option value="IT Park Facade">IT Park & Office Architectural Facade</option>
                    <option value="Structural Glazing">Structural Glazing & Stainless Steel</option>
                    <option value="Residential Clubhouses">Luxury Homes & Clubhouses</option>
                    <option value="Heavy Infrastructure">Public Transit & Industrial Infrastructure</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">Project Requirements</label>
                  <textarea
                    rows={3}
                    placeholder="Briefly describe specifications, area, or timelines..."
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full bg-neutral-900 border border-white/15 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-white transition-colors resize-none"
                  />
                </div>

                <div className="pt-2 flex items-center justify-between">
                  <span className="text-xs text-neutral-400">Direct Consultation</span>
                  <button
                    type="submit"
                    className="bg-white text-black font-semibold text-sm px-6 py-2.5 rounded-full hover:bg-neutral-200 transition-all flex items-center gap-2 cursor-pointer shadow-lg"
                  >
                    <Send className="w-3.5 h-3.5" /> Submit Request
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* 2. Portfolio / Explore Our Work Modal */}
      {activeModal === 'portfolio' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="relative w-full max-w-4xl max-h-[90vh] bg-neutral-950 border border-white/20 rounded-3xl p-6 sm:p-8 text-white shadow-2xl flex flex-col overflow-hidden">
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <div>
                <span className="text-xs uppercase tracking-widest text-neutral-400 font-semibold">Featured Projects</span>
                <h3 className="text-2xl font-bold mt-0.5">National Fabrication Portfolio</h3>
              </div>
              <button
                onClick={() => setActiveModal(null)}
                className="w-9 h-9 rounded-full bg-neutral-900 border border-white/10 flex items-center justify-center hover:bg-neutral-800 transition-colors"
              >
                <X className="w-4 h-4 text-neutral-300" />
              </button>
            </div>

            <div className="overflow-y-auto pr-2 mt-6 space-y-5 flex-1">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* Project 1 */}
                <div className="rounded-2xl border border-white/15 bg-neutral-900/60 p-5 hover:border-white/40 transition-all group">
                  <div className="flex items-center justify-between text-xs text-neutral-400 mb-2">
                    <span>IT Corporate Park</span>
                    <span className="text-white font-medium">NCC Limited</span>
                  </div>
                  <h4 className="text-lg font-bold group-hover:text-neutral-200 transition-colors">
                    Hyper-Scale Architectural Facade & Louver Systems
                  </h4>
                  <p className="text-xs text-neutral-400 mt-2 leading-relaxed">
                    Designed and fabricated 45,000 sq.ft of precision aluminum composite, structural steel framework, and acoustic interior partitions for leading tech hub.
                  </p>
                  <div className="mt-4 flex items-center gap-2">
                    <span className="text-[10px] bg-white/10 text-neutral-300 px-2.5 py-1 rounded-full">Laser CNC</span>
                    <span className="text-[10px] bg-white/10 text-neutral-300 px-2.5 py-1 rounded-full">Structural Steel</span>
                    <span className="text-[10px] bg-white/10 text-neutral-300 px-2.5 py-1 rounded-full">Turnkey</span>
                  </div>
                </div>

                {/* Project 2 */}
                <div className="rounded-2xl border border-white/15 bg-neutral-900/60 p-5 hover:border-white/40 transition-all group">
                  <div className="flex items-center justify-between text-xs text-neutral-400 mb-2">
                    <span>Public Infrastructure</span>
                    <span className="text-white font-medium">KSRTC & Indian Railways</span>
                  </div>
                  <h4 className="text-lg font-bold group-hover:text-neutral-200 transition-colors">
                    Heavy-Duty Transit Hub Canopies & Passenger Concourse
                  </h4>
                  <p className="text-xs text-neutral-400 mt-2 leading-relaxed">
                    Turnkey fabrication of weather-resistant steel trusses, cantilevered canopies, and stainless steel crowd-management barriers.
                  </p>
                  <div className="mt-4 flex items-center gap-2">
                    <span className="text-[10px] bg-white/10 text-neutral-300 px-2.5 py-1 rounded-full">Canopy Truss</span>
                    <span className="text-[10px] bg-white/10 text-neutral-300 px-2.5 py-1 rounded-full">SS 304 Grade</span>
                    <span className="text-[10px] bg-white/10 text-neutral-300 px-2.5 py-1 rounded-full">High Durability</span>
                  </div>
                </div>

                {/* Project 3 */}
                <div className="rounded-2xl border border-white/15 bg-neutral-900/60 p-5 hover:border-white/40 transition-all group">
                  <div className="flex items-center justify-between text-xs text-neutral-400 mb-2">
                    <span>Power & Grid Stations</span>
                    <span className="text-white font-medium">KPTCL</span>
                  </div>
                  <h4 className="text-lg font-bold group-hover:text-neutral-200 transition-colors">
                    Substation Control Centers & High-Spec Enclosures
                  </h4>
                  <p className="text-xs text-neutral-400 mt-2 leading-relaxed">
                    Precision engineering of heavy-duty acoustic electrical enclosures, specialized server room framing, and safety-rated structural railings.
                  </p>
                  <div className="mt-4 flex items-center gap-2">
                    <span className="text-[10px] bg-white/10 text-neutral-300 px-2.5 py-1 rounded-full">Safety Certified</span>
                    <span className="text-[10px] bg-white/10 text-neutral-300 px-2.5 py-1 rounded-full">Heavy Fab</span>
                    <span className="text-[10px] bg-white/10 text-neutral-300 px-2.5 py-1 rounded-full">Custom Enclosure</span>
                  </div>
                </div>

                {/* Project 4 */}
                <div className="rounded-2xl border border-white/15 bg-neutral-900/60 p-5 hover:border-white/40 transition-all group">
                  <div className="flex items-center justify-between text-xs text-neutral-400 mb-2">
                    <span>Commercial & Banking</span>
                    <span className="text-white font-medium">Apex Bank & Rami Reddy</span>
                  </div>
                  <h4 className="text-lg font-bold group-hover:text-neutral-200 transition-colors">
                    Commercial Headquarters & Custom Glass Spiral Staircases
                  </h4>
                  <p className="text-xs text-neutral-400 mt-2 leading-relaxed">
                    Bespoke architectural metalworks featuring mirror-polish stainless steel handrails, curved glass railings, and entrance porticos.
                  </p>
                  <div className="mt-4 flex items-center gap-2">
                    <span className="text-[10px] bg-white/10 text-neutral-300 px-2.5 py-1 rounded-full">Curved Glass</span>
                    <span className="text-[10px] bg-white/10 text-neutral-300 px-2.5 py-1 rounded-full">Mirror Polish</span>
                    <span className="text-[10px] bg-white/10 text-neutral-300 px-2.5 py-1 rounded-full">Bespoke</span>
                  </div>
                </div>

              </div>
            </div>

            <div className="pt-4 border-t border-white/10 flex items-center justify-between">
              <span className="text-xs text-neutral-400">Over 2,000+ projects completed across India</span>
              <button
                onClick={() => {
                  setActiveModal('contact');
                }}
                className="bg-white text-black font-semibold text-xs sm:text-sm px-5 py-2 rounded-full hover:bg-neutral-200 transition-all"
              >
                Inquire For Your Project
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 3. About Us Modal */}
      {activeModal === 'about' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="relative w-full max-w-2xl bg-neutral-950 border border-white/20 rounded-3xl p-6 sm:p-8 text-white shadow-2xl">
            <button
              onClick={() => setActiveModal(null)}
              className="absolute top-5 right-5 w-8 h-8 rounded-full bg-neutral-900 border border-white/10 flex items-center justify-center hover:bg-neutral-800 transition-colors"
            >
              <X className="w-4 h-4 text-neutral-300" />
            </button>

            <span className="text-xs uppercase tracking-widest text-neutral-400 font-semibold">Since 2004 • 25 Years of Excellence</span>
            <h3 className="text-2xl font-bold mt-1">About National Fabrication</h3>
            
            <p className="text-sm text-neutral-300 mt-4 leading-relaxed">
              Established in 2004, <strong className="text-white">National Fabrication</strong> has emerged as a premier architectural, structural, and interior/exterior metal fabrication powerhouse headquartered in Karnataka, executing high-profile turnkey developments across India.
            </p>

            <div className="grid grid-cols-2 gap-4 mt-6">
              <div className="border border-white/10 rounded-2xl p-4 bg-neutral-900/50">
                <Building2 className="w-5 h-5 text-white mb-2" />
                <div className="text-sm font-bold">50,000+ sq.ft Works</div>
                <p className="text-xs text-neutral-400 mt-1">Equipped with CNC Fiber Laser, Press Brake Benders & Argon TIG/MIG stations.</p>
              </div>

              <div className="border border-white/10 rounded-2xl p-4 bg-neutral-900/50">
                <ShieldCheck className="w-5 h-5 text-white mb-2" />
                <div className="text-sm font-bold">Rigid Quality Audits</div>
                <p className="text-xs text-neutral-400 mt-1">ISO aligned material testing, weld penetration checks & structural warranties.</p>
              </div>

              <div className="border border-white/10 rounded-2xl p-4 bg-neutral-900/50">
                <Layers className="w-5 h-5 text-white mb-2" />
                <div className="text-sm font-bold">Turnkey Execution</div>
                <p className="text-xs text-neutral-400 mt-1">From architectural 3D CAD modeling to factory fabrication and on-site crane erection.</p>
              </div>

              <div className="border border-white/10 rounded-2xl p-4 bg-neutral-900/50">
                <Award className="w-5 h-5 text-white mb-2" />
                <div className="text-sm font-bold">Trusted by Titans</div>
                <p className="text-xs text-neutral-400 mt-1">Preferred vendor for Indian Railways, KSRTC, KPTCL, NCC Limited, and apex bodies.</p>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-white/10 flex items-center justify-between">
              <span className="text-xs text-neutral-400">Head Office: Jayanagar, near Dairy Circle, Bangalore</span>
              <button
                onClick={() => setActiveModal('contact')}
                className="bg-white text-black font-semibold text-xs px-5 py-2 rounded-full hover:bg-neutral-200 transition-all"
              >
                Contact Engineering Team
              </button>
            </div>
          </div>
        </div>
      )}
      {/* ===================== ALL PROJECTS OVERLAY ===================== */}
      {showAllProjects && (
        <AllProjectsPage onBack={() => setShowAllProjects(false)} />
      )}

    </div>
  );
}
